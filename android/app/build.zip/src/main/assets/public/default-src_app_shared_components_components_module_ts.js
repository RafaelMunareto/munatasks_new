(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["default-src_app_shared_components_components_module_ts"],{

/***/ 44981:
/*!**************************************************************************!*\
  !*** ./node_modules/ng2-search-filter/__ivy_ngcc__/ng2-search-filter.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ng2SearchPipeModule": () => (/* binding */ Ng2SearchPipeModule),
/* harmony export */   "Ng2SearchPipe": () => (/* binding */ Ng2SearchPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);



class Ng2SearchPipe {
    /**
     * @param {?} items object from array
     * @param {?} term term's search
     * @return {?}
     */
    transform(items, term) {
        if (!term || !items)
            return items;
        return Ng2SearchPipe.filter(items, term);
    }
    /**
     *
     * @param {?} items List of items to filter
     * @param {?} term  a string term to compare with every property of the list
     *
     * @return {?}
     */
    static filter(items, term) {
        const /** @type {?} */ toCompare = term.toLowerCase();
        /**
         * @param {?} item
         * @param {?} term
         * @return {?}
         */
        function checkInside(item, term) {
            for (let /** @type {?} */ property in item) {
                if (item[property] === null || item[property] == undefined) {
                    continue;
                }
                if (typeof item[property] === 'object') {
                    if (checkInside(item[property], term)) {
                        return true;
                    }
                }
                if (item[property].toString().toLowerCase().includes(toCompare)) {
                    return true;
                }
            }
            return false;
        }
        return items.filter(function (item) {
            return checkInside(item, term);
        });
    }
}
Ng2SearchPipe.ɵfac = function Ng2SearchPipe_Factory(t) { return new (t || Ng2SearchPipe)(); };
Ng2SearchPipe.ɵpipe = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "filter", type: Ng2SearchPipe, pure: false });
Ng2SearchPipe.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: Ng2SearchPipe, factory: Ng2SearchPipe.ɵfac });
/**
 * @nocollapse
 */
Ng2SearchPipe.ctorParameters = () => [];
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Ng2SearchPipe, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Pipe,
        args: [{
                name: 'filter',
                pure: false
            }]
    }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable
    }], null, null); })();

class Ng2SearchPipeModule {
}
Ng2SearchPipeModule.ɵfac = function Ng2SearchPipeModule_Factory(t) { return new (t || Ng2SearchPipeModule)(); };
Ng2SearchPipeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: Ng2SearchPipeModule });
Ng2SearchPipeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({});
/**
 * @nocollapse
 */
Ng2SearchPipeModule.ctorParameters = () => [];
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Ng2SearchPipeModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
        args: [{
                declarations: [Ng2SearchPipe],
                exports: [Ng2SearchPipe]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](Ng2SearchPipeModule, { declarations: [Ng2SearchPipe], exports: [Ng2SearchPipe] }); })();

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=ng2-search-filter.js.map

/***/ }),

/***/ 96994:
/*!**************************************************!*\
  !*** ./src/app/core/services/overlay.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OverlayService": () => (/* binding */ OverlayService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 80476);



let OverlayService = class OverlayService {
    constructor(alertCtrl, loadController, toastController) {
        this.alertCtrl = alertCtrl;
        this.loadController = loadController;
        this.toastController = toastController;
    }
    alert(options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create(options);
            yield alert.present();
            return alert;
        });
    }
    loading(options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadController.create(Object.assign({ message: 'Carregando...' }, options));
            yield loading.present();
            return loading;
        });
    }
    toast(options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create(Object.assign(Object.assign({ position: 'bottom', duration: 3000, animated: true, cssClass: 'overlay-toast', message: '' }, options), { buttons: [
                    {
                        text: 'OK',
                        role: 'Cancelar',
                    },
                ] }));
            yield toast.present();
            return toast;
        });
    }
};
OverlayService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController }
];
OverlayService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], OverlayService);



/***/ }),

/***/ 2808:
/*!*************************************************************************************!*\
  !*** ./src/app/shared/components/card-icone-contador/card-icone-contador.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CardIconeContadorComponent": () => (/* binding */ CardIconeContadorComponent),
/* harmony export */   "CardIconeContadorModule": () => (/* binding */ CardIconeContadorModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _card_icone_contador_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./card-icone-contador.scss */ 36001);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);




let CardIconeContadorComponent = class CardIconeContadorComponent {
    constructor() {
        this.data = 0;
        this.direct = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
};
CardIconeContadorComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    icone: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    direct: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
CardIconeContadorComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-card-icone-contador',
        template: `
    <ion-card
      id="ion-card"
      class="box-shadown-light pointer"
      style="min-width:10rem"
    >
      <ion-card-content (click)="direct.emit($event)">
        <ion-row class="ion-justify-content-between">
          <div class="flex-column">
            <ion-icon
              [name]="icone"
              slot="start"
              [color]="color"
              class="icon-2em"
            ></ion-icon>
            <ion-label>{{ label }}</ion-label>
          </div>
          <ion-text>
            <h1 class="bold size200">{{ data }}</h1>
          </ion-text>
        </ion-row>
      </ion-card-content>
    </ion-card>
  `,
        styles: [_card_icone_contador_scss__WEBPACK_IMPORTED_MODULE_0__.default]
    })
], CardIconeContadorComponent);

let CardIconeContadorModule = class CardIconeContadorModule {
};
CardIconeContadorModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [CardIconeContadorComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        exports: [CardIconeContadorComponent],
    })
], CardIconeContadorModule);



/***/ }),

/***/ 15626:
/*!********************************************************!*\
  !*** ./src/app/shared/components/components.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ng2-search-filter */ 44981);
/* harmony import */ var _segment_button_segment_button_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./segment-button/segment-button.module */ 39587);
/* harmony import */ var _etiqueta_item_etiqueta_item_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./etiqueta-item/etiqueta-item.module */ 23641);
/* harmony import */ var _task_item_task_item_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./task-item/task-item.module */ 86371);
/* harmony import */ var _menu_toggle_menu_toggle_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./menu-toggle/menu-toggle.module */ 30373);
/* harmony import */ var _validator_note_validator_note_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./validator-note/validator-note.module */ 20676);
/* harmony import */ var _logout_button_logout_button_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./logout-button/logout-button.module */ 85617);
/* harmony import */ var _input_icon_valid_input_icon_valid_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input-icon-valid/input-icon-valid.module */ 77583);
/* harmony import */ var _card_icone_contador_card_icone_contador_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./card-icone-contador/card-icone-contador.module */ 2808);
/* harmony import */ var _header_back_header_back_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./header-back/header-back.module */ 94437);
/* harmony import */ var _responsaveis_item_responsaveis_item_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./responsaveis-item/responsaveis-item.module */ 55918);
/* harmony import */ var _skeleton_list_skeleton_list_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./skeleton-list/skeleton-list.module */ 16685);
/* harmony import */ var _no_tasks_no_tasks_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./no-tasks/no-tasks.module */ 80778);
/* harmony import */ var _expandable_expandable_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./expandable/expandable.module */ 57254);
















let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.NgModule)({
        imports: [
            _task_item_task_item_module__WEBPACK_IMPORTED_MODULE_3__.TaskItemModule,
            _menu_toggle_menu_toggle_module__WEBPACK_IMPORTED_MODULE_4__.MenuToggleModule,
            _logout_button_logout_button_module__WEBPACK_IMPORTED_MODULE_6__.LogoutButtonModule,
            _validator_note_validator_note_module__WEBPACK_IMPORTED_MODULE_5__.ValidatorNoteModule,
            _input_icon_valid_input_icon_valid_module__WEBPACK_IMPORTED_MODULE_7__.InputIconValidModule,
            _card_icone_contador_card_icone_contador_module__WEBPACK_IMPORTED_MODULE_8__.CardIconeContadorModule,
            _header_back_header_back_module__WEBPACK_IMPORTED_MODULE_9__.HeaderBackModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_0__.Ng2SearchPipeModule,
            _etiqueta_item_etiqueta_item_module__WEBPACK_IMPORTED_MODULE_2__.EtiquetaItemModule,
            _responsaveis_item_responsaveis_item_module__WEBPACK_IMPORTED_MODULE_10__.ResponsaveisItemModule,
            _segment_button_segment_button_module__WEBPACK_IMPORTED_MODULE_1__.SegmentButtonModule,
            _skeleton_list_skeleton_list_module__WEBPACK_IMPORTED_MODULE_11__.SkeletonListModule,
            _no_tasks_no_tasks_module__WEBPACK_IMPORTED_MODULE_12__.NoTasksModule,
            _expandable_expandable_module__WEBPACK_IMPORTED_MODULE_13__.ExpandableModule
        ],
        exports: [
            _task_item_task_item_module__WEBPACK_IMPORTED_MODULE_3__.TaskItemModule,
            _menu_toggle_menu_toggle_module__WEBPACK_IMPORTED_MODULE_4__.MenuToggleModule,
            _logout_button_logout_button_module__WEBPACK_IMPORTED_MODULE_6__.LogoutButtonModule,
            _validator_note_validator_note_module__WEBPACK_IMPORTED_MODULE_5__.ValidatorNoteModule,
            _input_icon_valid_input_icon_valid_module__WEBPACK_IMPORTED_MODULE_7__.InputIconValidModule,
            _card_icone_contador_card_icone_contador_module__WEBPACK_IMPORTED_MODULE_8__.CardIconeContadorModule,
            _header_back_header_back_module__WEBPACK_IMPORTED_MODULE_9__.HeaderBackModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_0__.Ng2SearchPipeModule,
            _etiqueta_item_etiqueta_item_module__WEBPACK_IMPORTED_MODULE_2__.EtiquetaItemModule,
            _responsaveis_item_responsaveis_item_module__WEBPACK_IMPORTED_MODULE_10__.ResponsaveisItemModule,
            _segment_button_segment_button_module__WEBPACK_IMPORTED_MODULE_1__.SegmentButtonModule,
            _skeleton_list_skeleton_list_module__WEBPACK_IMPORTED_MODULE_11__.SkeletonListModule,
            _no_tasks_no_tasks_module__WEBPACK_IMPORTED_MODULE_12__.NoTasksModule,
            _expandable_expandable_module__WEBPACK_IMPORTED_MODULE_13__.ExpandableModule
        ],
    })
], ComponentsModule);



/***/ }),

/***/ 25703:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/etiqueta-item/etiqueta-item.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaItemComponent": () => (/* binding */ EtiquetaItemComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_etiqueta_item_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./etiqueta-item.component.html */ 18197);
/* harmony import */ var _etiqueta_item_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etiqueta-item.component.scss */ 14974);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);




let EtiquetaItemComponent = class EtiquetaItemComponent {
    constructor() {
        this.update = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.delete = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.detail = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
};
EtiquetaItemComponent.propDecorators = {
    etiqueta: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    update: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }],
    delete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }],
    detail: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
EtiquetaItemComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-etiqueta-item',
        template: _raw_loader_etiqueta_item_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_etiqueta_item_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EtiquetaItemComponent);



/***/ }),

/***/ 23641:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/etiqueta-item/etiqueta-item.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaItemModule": () => (/* binding */ EtiquetaItemModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _etiqueta_item_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./etiqueta-item.component */ 25703);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);




let EtiquetaItemModule = class EtiquetaItemModule {
};
EtiquetaItemModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_etiqueta_item_component__WEBPACK_IMPORTED_MODULE_0__.EtiquetaItemComponent],
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        exports: [_etiqueta_item_component__WEBPACK_IMPORTED_MODULE_0__.EtiquetaItemComponent],
    })
], EtiquetaItemModule);



/***/ }),

/***/ 71623:
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/expandable/expandable.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExpandableComponent": () => (/* binding */ ExpandableComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_expandable_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./expandable.component.html */ 26205);
/* harmony import */ var _expandable_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./expandable.component.scss */ 96633);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/animations */ 17238);



/* eslint-disable @angular-eslint/no-input-rename */


let ExpandableComponent = class ExpandableComponent {
    constructor(renderer) {
        this.renderer = renderer;
        this.expanded = false;
        this.expandHeight = '150px';
        this.isOpen = true;
    }
    ngAfterViewInit() {
        this.renderer.setStyle(this.expandWrapper.nativeElement, 'max-height', this.expandHeight);
    }
};
ExpandableComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Renderer2 }
];
ExpandableComponent.propDecorators = {
    expandWrapper: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.ViewChild, args: ['expandWrapper', { read: _angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef },] }],
    expanded: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input, args: ['expanded',] }],
    expandHeight: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input, args: ['expandHeight',] }],
    isOpen: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
ExpandableComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-expandable',
        template: _raw_loader_expandable_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        animations: [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.trigger)('slideInOut', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.state)('in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.style)({
                    height: '0px',
                })),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.state)('out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.style)({
                    height: '250px',
                })),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.transition)('in => out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.animate)('600ms ease-in-out')),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.transition)('out => in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_4__.animate)('600ms ease-in-out')),
            ]),
        ],
        styles: [_expandable_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ExpandableComponent);



/***/ }),

/***/ 57254:
/*!*******************************************************************!*\
  !*** ./src/app/shared/components/expandable/expandable.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExpandableModule": () => (/* binding */ ExpandableModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _expandable_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./expandable.component */ 71623);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);




let ExpandableModule = class ExpandableModule {
};
ExpandableModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_expandable_component__WEBPACK_IMPORTED_MODULE_0__.ExpandableComponent],
        imports: [
            _shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule
        ],
        exports: [
            _expandable_component__WEBPACK_IMPORTED_MODULE_0__.ExpandableComponent
        ]
    })
], ExpandableModule);



/***/ }),

/***/ 94437:
/*!*********************************************************************!*\
  !*** ./src/app/shared/components/header-back/header-back.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderBackComponent": () => (/* binding */ HeaderBackComponent),
/* harmony export */   "HeaderBackModule": () => (/* binding */ HeaderBackModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);



let HeaderBackComponent = class HeaderBackComponent {
};
HeaderBackComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input }],
    route: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input }]
};
HeaderBackComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-header-back',
        template: ` <ion-header>
    <ion-toolbar color="primary">
      <ion-buttons slot="start">
        <ion-back-button text="Voltar" [defaultHref]="route"></ion-back-button>
      </ion-buttons>
      <ion-title>{{ title }}</ion-title>
    </ion-toolbar>
  </ion-header>`,
    })
], HeaderBackComponent);

let HeaderBackModule = class HeaderBackModule {
};
HeaderBackModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        declarations: [HeaderBackComponent],
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule],
        exports: [HeaderBackComponent],
    })
], HeaderBackModule);



/***/ }),

/***/ 77583:
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/input-icon-valid/input-icon-valid.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InputIconValidModule": () => (/* binding */ InputIconValidModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _validator_note_validator_note_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../validator-note/validator-note.module */ 20676);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);
/* harmony import */ var _input_icon_valild_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./input-icon-valild.component */ 93603);





let InputIconValidModule = class InputIconValidModule {
};
InputIconValidModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_input_icon_valild_component__WEBPACK_IMPORTED_MODULE_2__.InputIconValildComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _validator_note_validator_note_module__WEBPACK_IMPORTED_MODULE_0__.ValidatorNoteModule],
        exports: [_input_icon_valild_component__WEBPACK_IMPORTED_MODULE_2__.InputIconValildComponent],
    })
], InputIconValidModule);



/***/ }),

/***/ 93603:
/*!***********************************************************************************!*\
  !*** ./src/app/shared/components/input-icon-valid/input-icon-valild.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InputIconValildComponent": () => (/* binding */ InputIconValildComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);


let InputIconValildComponent = class InputIconValildComponent {
    constructor() {
        this.inputmode = 'text';
        this.type = 'text';
        this.autofocus = false;
        this.color = 'primary';
        this.slot = 'start';
    }
    ngOnInit() {
        switch (this.name) {
            case 'email':
                this.icone = 'mail';
                this.type = 'email';
                this.inputmode = 'text';
                this.placeholder = 'E-mail';
                break;
            case 'password':
                this.icone = 'lock-closed-outline';
                this.inputmode = 'password';
                this.type = 'password';
                this.placeholder = 'Senha';
                break;
            case 'confirmPassword':
                this.icone = 'lock-closed';
                this.inputmode = 'password';
                this.type = 'password';
                this.placeholder = 'Confirma Senha';
                break;
            case 'name':
                this.icone = 'person';
                this.inputmode = 'text';
                this.placeholder = 'Nome';
                break;
            default:
                this.icone = 'document-text-outline';
                this.inputmode = 'text';
                this.placeholder = this.name;
        }
    }
};
InputIconValildComponent.propDecorators = {
    form: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    icone: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    inputmode: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    name: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    placeholder: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    autofocus: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    slot: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }]
};
InputIconValildComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Component)({
        selector: 'app-input-icon-valild',
        template: `
    <form [formGroup]="form">
      <ion-item>
        <ion-icon [name]="icone" [color]="color" [slot]="slot"></ion-icon>
        <ion-input
          [type]="type"
          [placeholder]="placeholder"
          [inputmode]="inputmode"
          [formControlName]="name"
          [autofocus]="autofocus"
        >
        </ion-input>
        <app-validator-note
          [form-control]="$any(form.get(name))"
        ></app-validator-note>
      </ion-item>
    </form>
  `,
    })
], InputIconValildComponent);



/***/ }),

/***/ 43104:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/logout-button/logout-button.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LogoutButtonComponent": () => (/* binding */ LogoutButtonComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_logout_button_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./logout-button.component.html */ 28657);
/* harmony import */ var _logout_button_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logout-button.component.scss */ 27229);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/services/overlay.service */ 96994);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ 86710);









let LogoutButtonComponent = class LogoutButtonComponent {
    constructor(authService, navCtrl, menuCtrl, overlayService, store) {
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.overlayService = overlayService;
        this.store = store;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (!(yield this.menuCtrl.isEnabled(this.menu))) {
                this.menuCtrl.enable(true, this.menu);
            }
        });
    }
    logout() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.overlayService.alert({
                message: 'Você realmente quer sair?',
                buttons: [
                    {
                        text: 'SIM',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                            yield this.authService.logout();
                            this.navCtrl.navigateRoot('/login');
                            this.menuCtrl.enable(false, this.menu);
                            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.ClearEtiquetas)());
                            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.ClearResponsavel)());
                            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.ClearTasks)());
                        }),
                    },
                    'NÃO',
                ],
            });
        });
    }
};
LogoutButtonComponent.ctorParameters = () => [
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_4__.OverlayService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_7__.Store }
];
LogoutButtonComponent.propDecorators = {
    menu: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
LogoutButtonComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-logout-button',
        template: _raw_loader_logout_button_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_logout_button_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LogoutButtonComponent);



/***/ }),

/***/ 85617:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/logout-button/logout-button.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LogoutButtonModule": () => (/* binding */ LogoutButtonModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _logout_button_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./logout-button.component */ 43104);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);




let LogoutButtonModule = class LogoutButtonModule {
};
LogoutButtonModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_logout_button_component__WEBPACK_IMPORTED_MODULE_0__.LogoutButtonComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        exports: [_logout_button_component__WEBPACK_IMPORTED_MODULE_0__.LogoutButtonComponent],
    })
], LogoutButtonModule);



/***/ }),

/***/ 41739:
/*!************************************************************************!*\
  !*** ./src/app/shared/components/menu-toggle/menu-toggle.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuToggleComponent": () => (/* binding */ MenuToggleComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_menu_toggle_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./menu-toggle.component.html */ 82390);
/* harmony import */ var _menu_toggle_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu-toggle.component.scss */ 35323);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);




let MenuToggleComponent = class MenuToggleComponent {
    constructor() {
        this.menu = 'main-menu';
        this.title = '';
    }
};
MenuToggleComponent.ctorParameters = () => [];
MenuToggleComponent.propDecorators = {
    menu: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
MenuToggleComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-menu-toggle',
        template: _raw_loader_menu_toggle_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menu_toggle_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MenuToggleComponent);



/***/ }),

/***/ 30373:
/*!*********************************************************************!*\
  !*** ./src/app/shared/components/menu-toggle/menu-toggle.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuToggleModule": () => (/* binding */ MenuToggleModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _logout_button_logout_button_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../logout-button/logout-button.module */ 85617);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _menu_toggle_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu-toggle.component */ 41739);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared.module */ 44466);





let MenuToggleModule = class MenuToggleModule {
};
MenuToggleModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_menu_toggle_component__WEBPACK_IMPORTED_MODULE_1__.MenuToggleComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _logout_button_logout_button_module__WEBPACK_IMPORTED_MODULE_0__.LogoutButtonModule],
        exports: [_menu_toggle_component__WEBPACK_IMPORTED_MODULE_1__.MenuToggleComponent],
    })
], MenuToggleModule);



/***/ }),

/***/ 42089:
/*!******************************************************************!*\
  !*** ./src/app/shared/components/no-tasks/no-tasks.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoTasksComponent": () => (/* binding */ NoTasksComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);


let NoTasksComponent = class NoTasksComponent {
};
NoTasksComponent.propDecorators = {
    msg: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }]
};
NoTasksComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Component)({
        selector: 'app-no-tasks',
        template: ` <ion-item lines="none" color="warning">{{ msg }}</ion-item> `,
    })
], NoTasksComponent);



/***/ }),

/***/ 80778:
/*!***************************************************************!*\
  !*** ./src/app/shared/components/no-tasks/no-tasks.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoTasksModule": () => (/* binding */ NoTasksModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _no_tasks_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./no-tasks.component */ 42089);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);




let NoTasksModule = class NoTasksModule {
};
NoTasksModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_no_tasks_component__WEBPACK_IMPORTED_MODULE_0__.NoTasksComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        exports: [_no_tasks_component__WEBPACK_IMPORTED_MODULE_0__.NoTasksComponent],
    })
], NoTasksModule);



/***/ }),

/***/ 47520:
/*!************************************************************************************!*\
  !*** ./src/app/shared/components/responsaveis-item/responsaveis-item.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisItemComponent": () => (/* binding */ ResponsaveisItemComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_responsaveis_item_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./responsaveis-item.component.html */ 3006);
/* harmony import */ var _responsaveis_item_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./responsaveis-item.component.scss */ 18403);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);




let ResponsaveisItemComponent = class ResponsaveisItemComponent {
    constructor() {
        this.update = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.delete = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    ngOnInit() { }
};
ResponsaveisItemComponent.ctorParameters = () => [];
ResponsaveisItemComponent.propDecorators = {
    responsaveis: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    update: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }],
    delete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
ResponsaveisItemComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-responsaveis-item',
        template: _raw_loader_responsaveis_item_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_responsaveis_item_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ResponsaveisItemComponent);



/***/ }),

/***/ 55918:
/*!*********************************************************************************!*\
  !*** ./src/app/shared/components/responsaveis-item/responsaveis-item.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisItemModule": () => (/* binding */ ResponsaveisItemModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _responsaveis_item_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./responsaveis-item.component */ 47520);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);




let ResponsaveisItemModule = class ResponsaveisItemModule {
};
ResponsaveisItemModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_responsaveis_item_component__WEBPACK_IMPORTED_MODULE_0__.ResponsaveisItemComponent],
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        exports: [_responsaveis_item_component__WEBPACK_IMPORTED_MODULE_0__.ResponsaveisItemComponent],
    })
], ResponsaveisItemModule);



/***/ }),

/***/ 39908:
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/segment-button/segment-button.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SegmentButtonComponent": () => (/* binding */ SegmentButtonComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_segment_button_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./segment-button.component.html */ 21905);
/* harmony import */ var _segment_button_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./segment-button.component.scss */ 85252);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ 17324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 45435);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var src_app_pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/pages/dashboard/tasks/services/tasks.service */ 42660);
/* harmony import */ var _functions_tasks_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../functions/tasks-functions */ 29025);
/* harmony import */ var src_app_core_services_overlay_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/overlay.service */ 96994);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 38583);



/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable prefer-const */











let SegmentButtonComponent = class SegmentButtonComponent {
    constructor(navCtrl, store, router, localNotifications, alertController, tasksService, TasksFunctions, overlayService) {
        this.navCtrl = navCtrl;
        this.store = store;
        this.router = router;
        this.localNotifications = localNotifications;
        this.alertController = alertController;
        this.tasksService = tasksService;
        this.TasksFunctions = TasksFunctions;
        this.overlayService = overlayService;
        this.fase = 'home';
        this.alert = [];
    }
    ngOnInit() {
        this.router.events
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)((e) => e instanceof _angular_router__WEBPACK_IMPORTED_MODULE_8__.NavigationEnd))
            .subscribe((e) => {
            const url = e.url;
            if (url === '/tasks') {
                this.fase = 'home';
                this.slideChanged(`home`);
            }
            else if (url === `/tasks/create`) {
                this.slideChanged(`create`);
            }
            else {
                this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_9__.select)('selectBox'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.take)(2)).subscribe((data) => {
                    var _a;
                    this.fase = (_a = data.fase) !== null && _a !== void 0 ? _a : 'home';
                    this.slideChanged(this.fase);
                });
            }
        });
    }
    segmentChanged(event) {
        this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_9__.select)(`tasks`), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.take)(1)).subscribe((res) => {
            this.notificationsAcionar(res.alert);
        });
        const e = typeof event === 'string' ? event : event.target.value;
        switch (e) {
            case 'home':
                this.navCtrl.navigateBack(['/tasks']);
                break;
            case 'create':
                this.navCtrl.navigateRoot(['/tasks/create']);
                this.slideChanged(`create`);
                break;
            default:
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddSelectionEtiqueta)('todos'));
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddSelectionFase)(e));
                this.slideChanged(e);
                this.navCtrl.navigateRoot(['/tasks/list']);
        }
    }
    slideChanged(fase) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const el = document.getElementById(`segment-${fase}`);
            yield (el === null || el === void 0 ? void 0 : el.scrollIntoView({
                behavior: 'smooth',
                block: 'center',
                inline: 'center',
            }));
        });
    }
    presentAlert(task) {
        var _a, _b, _c, _d;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            if (task.responsavel) {
                const alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    header: `Notifcação ${task.tipo}`,
                    subHeader: `${(_a = task.responsavel[0]) !== null && _a !== void 0 ? _a : ''} ${(_b = task.responsavel[1]) !== null && _b !== void 0 ? _b : ''} ${(_c = task.responsavel[2]) !== null && _c !== void 0 ? _c : ''} ${(_d = task.responsavel[3]) !== null && _d !== void 0 ? _d : ''}`,
                    message: task.title,
                    translucent: true,
                    animated: true,
                    inputs: [
                        {
                            name: 'Adiar 30 min',
                            type: 'radio',
                            label: 'Adiar 30 min',
                            value: 1800000,
                            handler: () => {
                                this.radio = 1800000;
                            },
                        },
                        {
                            name: 'Adiar 1 hora',
                            type: 'radio',
                            label: 'Adiar 1 hora',
                            value: 3600000,
                            handler: () => {
                                this.radio = 3600000;
                            },
                        },
                        {
                            name: 'Adiar 1 dia',
                            type: 'radio',
                            label: 'Adiar 1 dia',
                            value: 86400000,
                            handler: () => {
                                this.radio = 86400000;
                            },
                        },
                    ],
                    buttons: [
                        {
                            text: 'OK',
                            handler: () => {
                                if (this.radio) {
                                    this.onHoje(task, this.radio);
                                }
                            },
                        },
                    ],
                });
                yield alert.present();
                const { role } = yield alert.onDidDismiss();
            }
        });
    }
    notifications(task) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            // this.localNotifications.schedule({
            //   id: task.id,
            //   text: task.title,
            //   data: { secret: task.id },
            //   icon: 'alert-circle-outline',
            //   smallIcon: 'alert-circle-outline',
            //   led: 'FF0000',
            // });
        });
    }
    simpleNotif(tasks) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            if (tasks !== undefined) {
                for (let task of tasks) {
                    yield this.presentAlert(task);
                    yield this.notifications(task);
                }
            }
        });
    }
    onHoje(task, time) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            let timer = 0;
            if (time === 30) {
                timer = 1800000;
            }
            else if (time === 60) {
                timer = 3600000;
            }
            else if (time === 2) {
                timer = 86400000;
            }
            const date = (0,_angular_common__WEBPACK_IMPORTED_MODULE_12__.formatDate)(new Date().getTime() + timer, "yyyy-MM-dd'T'HH:mm", 'en');
            const taskToUpdate = Object.assign(Object.assign({}, task), { data: date });
            setTimeout(() => {
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddTasks)([taskToUpdate]));
                this.tasksService.update(taskToUpdate);
            }, 400);
            yield this.overlayService.toast({
                message: `Tarefa ${task.title} ${taskToUpdate.done ? 'Atualizada' : 'Atualizada'}!`,
            });
        });
    }
    notificationsAcionar(alert) {
        this.simpleNotif(alert);
    }
};
SegmentButtonComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.NavController },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_9__.Store },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_2__.LocalNotifications },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.AlertController },
    { type: src_app_pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService },
    { type: _functions_tasks_functions__WEBPACK_IMPORTED_MODULE_5__.TasksFunctions },
    { type: src_app_core_services_overlay_service__WEBPACK_IMPORTED_MODULE_6__.OverlayService }
];
SegmentButtonComponent.propDecorators = {
    contador: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_14__.Input }]
};
SegmentButtonComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-segment-button',
        template: _raw_loader_segment_button_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_segment_button_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SegmentButtonComponent);



/***/ }),

/***/ 39587:
/*!***************************************************************************!*\
  !*** ./src/app/shared/components/segment-button/segment-button.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SegmentButtonModule": () => (/* binding */ SegmentButtonModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _segment_button_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./segment-button.component */ 39908);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);
/* harmony import */ var _directives_directives_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../directives/directives.module */ 35540);
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ 17324);
/* harmony import */ var src_app_pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/pages/dashboard/tasks/services/tasks.service */ 42660);
/* harmony import */ var _functions_tasks_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../functions/tasks-functions */ 29025);








let SegmentButtonModule = class SegmentButtonModule {
};
SegmentButtonModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        declarations: [_segment_button_component__WEBPACK_IMPORTED_MODULE_0__.SegmentButtonComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _directives_directives_module__WEBPACK_IMPORTED_MODULE_2__.DirectivesModule],
        exports: [_segment_button_component__WEBPACK_IMPORTED_MODULE_0__.SegmentButtonComponent],
        providers: [_ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_3__.LocalNotifications, src_app_pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService, _functions_tasks_functions__WEBPACK_IMPORTED_MODULE_5__.TasksFunctions],
    })
], SegmentButtonModule);



/***/ }),

/***/ 10806:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/skeleton-list/skeleton-list.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SkeletonListComponent": () => (/* binding */ SkeletonListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);


let SkeletonListComponent = class SkeletonListComponent {
    constructor() {
        this.qtd = 10;
        this.heigth = '3rem';
    }
};
SkeletonListComponent.propDecorators = {
    qtd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    heigth: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }]
};
SkeletonListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Component)({
        selector: 'app-skeleton-list',
        template: `
    <div class="ion-padding custom-skeleton">
      <ion-skeleton-text
        *ngFor="let item of [].constructor(qtd); let i = index"
        animated
        ng-repeat="n in range(5,15)"
        [style]="'height: ' + heigth + '; border-radius:10px'"
      ></ion-skeleton-text>
    </div>
  `,
    })
], SkeletonListComponent);



/***/ }),

/***/ 16685:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/skeleton-list/skeleton-list.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SkeletonListModule": () => (/* binding */ SkeletonListModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _skeleton_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./skeleton-list.component */ 10806);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);




let SkeletonListModule = class SkeletonListModule {
};
SkeletonListModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_skeleton_list_component__WEBPACK_IMPORTED_MODULE_0__.SkeletonListComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        exports: [_skeleton_list_component__WEBPACK_IMPORTED_MODULE_0__.SkeletonListComponent],
    })
], SkeletonListModule);



/***/ }),

/***/ 57880:
/*!********************************************************************!*\
  !*** ./src/app/shared/components/task-item/task-item.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskItemComponent": () => (/* binding */ TaskItemComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_task_item_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./task-item.component.html */ 82546);
/* harmony import */ var _task_item_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./task-item.component.scss */ 49941);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/services/overlay.service */ 96994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/animations */ 17238);
/* harmony import */ var src_app_pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pages/dashboard/tasks/services/tasks.service */ 42660);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/ngrx/actions/action-types */ 65221);









let TaskItemComponent = class TaskItemComponent {
    constructor(overlayService, tasksService, store) {
        this.overlayService = overlayService;
        this.tasksService = tasksService;
        this.store = store;
        this.isOpen = true;
        this.animation = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.done = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.update = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.delete = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.sinalizada = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.hoje = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
    }
    ngOnInit() {
        this.tipo = this.task.tipo;
    }
    onToggle() {
        this.isOpen = !this.isOpen;
    }
    onDelete(task) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            yield this.overlayService.alert({
                message: `Tem certeza que deseja excluír a tarefa ${task.title} ?`,
                buttons: [
                    {
                        text: 'Sim',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                            yield this.tasksService.delete(task);
                            yield this.overlayService.toast({
                                message: `Tarefa ${task.title} deletada!`,
                            });
                            this.isOpen = false;
                            setTimeout(() => {
                                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_4__.RemoveTasks)(task.id));
                            }, 400);
                        }),
                    },
                    'Não',
                ],
            });
        });
    }
};
TaskItemComponent.ctorParameters = () => [
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_2__.OverlayService },
    { type: src_app_pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_3__.TasksService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_7__.Store }
];
TaskItemComponent.propDecorators = {
    task: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    isOpen: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    animation: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    done: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    update: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    delete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    sinalizada: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    hoje: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }]
};
TaskItemComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-task-item',
        template: _raw_loader_task_item_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        animations: [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.trigger)('slideInOut', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.state)('in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
                    right: '0%',
                    backgroundColor: 'rgba(0, 0, 0, 1)',
                })),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.state)('out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
                    right: '-400%',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                })),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)('in => out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animate)('400ms ease-in-out')),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)('out => in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animate)('400ms ease-in-out')),
            ]),
        ],
        styles: [_task_item_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TaskItemComponent);



/***/ }),

/***/ 86371:
/*!*****************************************************************!*\
  !*** ./src/app/shared/components/task-item/task-item.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskItemModule": () => (/* binding */ TaskItemModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _task_item_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./task-item.component */ 57880);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);
/* harmony import */ var _directives_directives_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../directives/directives.module */ 35540);





let TaskItemModule = class TaskItemModule {
};
TaskItemModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_task_item_component__WEBPACK_IMPORTED_MODULE_0__.TaskItemComponent],
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _directives_directives_module__WEBPACK_IMPORTED_MODULE_2__.DirectivesModule],
        exports: [_task_item_component__WEBPACK_IMPORTED_MODULE_0__.TaskItemComponent],
    })
], TaskItemModule);



/***/ }),

/***/ 59247:
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/validator-note/validator-note.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValidatorNoteComponent": () => (/* binding */ ValidatorNoteComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 3679);



let ValidatorNoteComponent = class ValidatorNoteComponent {
    constructor() {
        // eslint-disable-next-line @angular-eslint/no-input-rename
        this.formControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl();
        this.formControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl();
    }
    ngOnInit() { }
    get errorMessage() {
        if (this.mustShowErrorMessage()) {
            return this.getErrorMessage();
        }
        else {
            return null;
        }
    }
    mustShowErrorMessage() {
        return this.formControl.invalid && this.formControl.touched;
    }
    getErrorMessage() {
        var _a, _b, _c, _d, _e, _f;
        if ((_a = this.formControl.errors) === null || _a === void 0 ? void 0 : _a.required) {
            return 'Dado obrigatório';
        }
        else if ((_b = this.formControl.errors) === null || _b === void 0 ? void 0 : _b.email) {
            return 'Email inválido';
        }
        else if ((_c = this.formControl.errors) === null || _c === void 0 ? void 0 : _c.minlength) {
            const requiredLength = this.formControl.errors.minlength.requiredLength;
            return `Mínimo ${requiredLength} caracteres`;
        }
        else if ((_d = this.formControl.errors) === null || _d === void 0 ? void 0 : _d.maxlength) {
            const requiredLength = this.formControl.errors.maxlength.requiredLength;
            return `Máximo ${requiredLength} caracteres`;
        }
        else if ((_e = this.formControl.errors) === null || _e === void 0 ? void 0 : _e.lowerCase) {
            return 'Devem ser mínusculas';
        }
        else if ((_f = this.formControl.errors) === null || _f === void 0 ? void 0 : _f.mustMatch) {
            return 'Devem ser iguais';
        }
        return null;
    }
};
ValidatorNoteComponent.ctorParameters = () => [];
ValidatorNoteComponent.propDecorators = {
    formControl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input, args: ['form-control',] }]
};
ValidatorNoteComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-validator-note',
        template: `
    <ion-note
      slot="end"
      class="size80"
      color="danger"
      severity="error"
      *ngIf="errorMessage"
    >
      {{ errorMessage }}
    </ion-note>
  `,
    })
], ValidatorNoteComponent);



/***/ }),

/***/ 20676:
/*!***************************************************************************!*\
  !*** ./src/app/shared/components/validator-note/validator-note.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValidatorNoteModule": () => (/* binding */ ValidatorNoteModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _validator_note_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validator-note.component */ 59247);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared.module */ 44466);




let ValidatorNoteModule = class ValidatorNoteModule {
};
ValidatorNoteModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
        declarations: [_validator_note_component__WEBPACK_IMPORTED_MODULE_0__.ValidatorNoteComponent],
        exports: [_validator_note_component__WEBPACK_IMPORTED_MODULE_0__.ValidatorNoteComponent],
    })
], ValidatorNoteModule);



/***/ }),

/***/ 35540:
/*!********************************************************!*\
  !*** ./src/app/shared/directives/directives.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DirectivesModule": () => (/* binding */ DirectivesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _task_tipos_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./task-tipos.directive */ 53884);
/* harmony import */ var _etiqueta_colors_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./etiqueta-colors.directive */ 40197);





let DirectivesModule = class DirectivesModule {
};
DirectivesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_task_tipos_directive__WEBPACK_IMPORTED_MODULE_1__.TaskTiposDirective, _etiqueta_colors_directive__WEBPACK_IMPORTED_MODULE_2__.EtiquetaColorsDirective],
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule],
        exports: [_task_tipos_directive__WEBPACK_IMPORTED_MODULE_1__.TaskTiposDirective, _etiqueta_colors_directive__WEBPACK_IMPORTED_MODULE_2__.EtiquetaColorsDirective],
    })
], DirectivesModule);



/***/ }),

/***/ 40197:
/*!****************************************************************!*\
  !*** ./src/app/shared/directives/etiqueta-colors.directive.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaColorsDirective": () => (/* binding */ EtiquetaColorsDirective)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 3679);



let EtiquetaColorsDirective = class EtiquetaColorsDirective {
    constructor(el, control) {
        this.el = el;
        this.control = control;
    }
    onNgModelChange(event) {
        this.badge(event);
    }
    ngOnInit() { }
    badge(dados) {
        switch (dados) {
            case 'danger':
                return (this.el.nativeElement.style.color = '#eb445a');
                break;
            case 'primary':
                return (this.el.nativeElement.style.color = '#3880ff');
                break;
            case 'warning':
                return (this.el.nativeElement.style.color = '#ffc409');
                break;
            case 'secondary':
                return (this.el.nativeElement.style.color = '#3dc2ff');
                break;
            case 'success':
                return (this.el.nativeElement.style.color = '#2dd36f');
                break;
            case 'dark':
                return (this.el.nativeElement.style.color = '#222428');
                break;
            case 'medium':
                return (this.el.nativeElement.style.color = '#92949c');
                break;
            default:
                return (this.el.nativeElement.style.color = '#808080');
                break;
        }
    }
};
EtiquetaColorsDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControl }
];
EtiquetaColorsDirective.propDecorators = {
    onNgModelChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener, args: ['ngModelChange', ['$event'],] }]
};
EtiquetaColorsDirective = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive)({
        selector: '[appEtiquetasColors]',
    })
], EtiquetaColorsDirective);



/***/ }),

/***/ 53884:
/*!***********************************************************!*\
  !*** ./src/app/shared/directives/task-tipos.directive.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskTiposDirective": () => (/* binding */ TaskTiposDirective)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 3679);



let TaskTiposDirective = class TaskTiposDirective {
    constructor(el, control) {
        this.el = el;
        this.control = control;
    }
    onNgModelChange(event) {
        const cor = this.dados.find((element) => element.nome === event);
        if (cor) {
            this.badge(cor.cor);
        }
    }
    badge(dados) {
        switch (dados) {
            case 'danger':
                return (this.el.nativeElement.style.color = '#eb445a');
                break;
            case 'primary':
                return (this.el.nativeElement.style.color = '#3880ff');
                break;
            case 'warning':
                return (this.el.nativeElement.style.color = '#ffc409');
                break;
            case 'secondary':
                return (this.el.nativeElement.style.color = '#3dc2ff');
                break;
            case 'success':
                return (this.el.nativeElement.style.color = '#2dd36f');
                break;
            case 'dark':
                return (this.el.nativeElement.style.color = '#222428');
                break;
            case 'medium':
                return (this.el.nativeElement.style.color = '#92949c');
                break;
            default:
                return (this.el.nativeElement.style.color = '#808080');
                break;
        }
    }
};
TaskTiposDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControl }
];
TaskTiposDirective.propDecorators = {
    dados: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input, args: ['appTaskTipos',] }],
    onNgModelChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener, args: ['ngModelChange', ['$event'],] }]
};
TaskTiposDirective = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive)({
        selector: '[appTaskTipos]',
    })
], TaskTiposDirective);



/***/ }),

/***/ 29025:
/*!*****************************************************!*\
  !*** ./src/app/shared/functions/tasks-functions.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksFunctions": () => (/* binding */ TasksFunctions)
/* harmony export */ });
class TasksFunctions {
    corEtiqueta(tipo, etiquetas) {
        try {
            const cor = etiquetas.find((element) => element.nome === tipo);
            return cor.cor;
        }
        catch (e) {
            return;
        }
    }
    cor(faseParam, color) {
        switch (faseParam) {
            case 'hoje':
                color = 'primary';
                break;
            case 'abertos':
                color = 'success';
                break;
            case 'sinalizados':
                color = 'warning';
                break;
            case 'todos':
                color = 'medium';
                break;
            case 'finalizados':
                color = 'primary';
                break;
        }
    }
}


/***/ }),

/***/ 36001:
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/card-icone-contador/card-icone-contador.scss ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#ion-card {\n  margin: 0.4rem !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcmQtaWNvbmUtY29udGFkb3Iuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0YiLCJmaWxlIjoiY2FyZC1pY29uZS1jb250YWRvci5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2lvbi1jYXJkIHtcclxuICBtYXJnaW46IDAuNHJlbSAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 14974:
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/etiqueta-item/etiqueta-item.component.scss ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJldGlxdWV0YS1pdGVtLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 96633:
/*!************************************************************************!*\
  !*** ./src/app/shared/components/expandable/expandable.component.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".expand-wrapper {\n  transition: max-height 1s ease-in-out;\n  overflow: auto;\n  height: auto;\n}\n\n.collapsed {\n  max-height: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV4cGFuZGFibGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQ0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx3QkFBQTtBQUVGIiwiZmlsZSI6ImV4cGFuZGFibGUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXhwYW5kLXdyYXBwZXIge1xyXG4gIHRyYW5zaXRpb246IG1heC1oZWlnaHQgMXMgZWFzZS1pbi1vdXQ7XHJcbiAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG59XHJcbi5jb2xsYXBzZWQge1xyXG4gIG1heC1oZWlnaHQ6IDAgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 27229:
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/logout-button/logout-button.component.scss ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb2dvdXQtYnV0dG9uLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 35323:
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/menu-toggle/menu-toggle.component.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZW51LXRvZ2dsZS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 18403:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/responsaveis-item/responsaveis-item.component.scss ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXNwb25zYXZlaXMtaXRlbS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 85252:
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/segment-button/segment-button.component.scss ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZWdtZW50LWJ1dHRvbi5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 49941:
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/task-item/task-item.component.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".icon:hover {\n  color: #1877f2;\n}\n\n.icon {\n  font-size: 1.5rem !important;\n}\n\n.my-custom-class {\n  --background: #222;\n  --box-shadow: 0 28px 48px rgba(0, 0, 0, 0.4);\n  --backdrop-opacity: var(--ion-backdrop-opacity, 0.32);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhc2staXRlbS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLDRDQUFBO0VBQ0EscURBQUE7QUFDRiIsImZpbGUiOiJ0YXNrLWl0ZW0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaWNvbjpob3ZlciB7XHJcbiAgY29sb3I6ICMxODc3ZjI7XHJcbn1cclxuXHJcbi5pY29uIHtcclxuICBmb250LXNpemU6IDEuNXJlbSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubXktY3VzdG9tLWNsYXNzIHtcclxuICAtLWJhY2tncm91bmQ6ICMyMjI7XHJcbiAgLS1ib3gtc2hhZG93OiAwIDI4cHggNDhweCByZ2JhKDAsIDAsIDAsIDAuNCk7XHJcbiAgLS1iYWNrZHJvcC1vcGFjaXR5OiB2YXIoLS1pb24tYmFja2Ryb3Atb3BhY2l0eSwgMC4zMik7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 18197:
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/etiqueta-item/etiqueta-item.component.html ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-item-sliding #sliding>\r\n\r\n  <ion-item>\r\n    <ion-badge [color]='etiqueta.cor'>{{ etiqueta.nome | titlecase }}</ion-badge>\r\n    <ion-note slot=\"end\">\r\n      <ion-icon\r\n        (click)='detail.emit(etiqueta)'\r\n        name=\"arrow-forward-outline\"\r\n        class='pointer'\r\n        color='primary'\r\n      ></ion-icon>\r\n    </ion-note>\r\n  </ion-item>\r\n\r\n  <ion-item-options side='start'>\r\n    <ion-item-option\r\n      color='danger'\r\n      (click)='delete.emit(etiqueta); sliding.close()'\r\n    >\r\n      <ion-icon\r\n        slot='icon-only'\r\n        name='trash'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n\r\n  <ion-item-options side='end'>\r\n    <ion-item-option (click)=\"update.emit(etiqueta); sliding.close()\">\r\n      <ion-icon\r\n        slot=\"icon-only\"\r\n        name='create'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n\r\n</ion-item-sliding>\r\n");

/***/ }),

/***/ 26205:
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/expandable/expandable.component.html ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<div [@slideInOut]=\"isOpen ? 'in' : 'out'\"  #expandWrapper class=\"expand-wrapper\" [class.collapsed]=\"!expanded\">\n  <ng-content></ng-content>\n</div>\n");

/***/ }),

/***/ 28657:
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/logout-button/logout-button.component.html ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-buttons>\r\n  <ion-button (click)='logout()'>\r\n    <ion-icon\r\n      name='exit'\r\n      slot='icon-only'\r\n    >\r\n    </ion-icon>\r\n  </ion-button>\r\n</ion-buttons>\r\n");

/***/ }),

/***/ 82390:
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/menu-toggle/menu-toggle.component.html ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot='start'>\r\n      <ion-menu-toggle [menu]='menu'>\r\n        <ion-button>\r\n          <ion-icon\r\n            slot='icon-only'\r\n            name='menu'\r\n          ></ion-icon>\r\n        </ion-button>\r\n      </ion-menu-toggle>\r\n    </ion-buttons>\r\n    <ion-title>{{ title }}</ion-title>\r\n    <app-logout-button\r\n      slot='end'\r\n      menu='main-menu'\r\n    ></app-logout-button>\r\n  </ion-toolbar>\r\n</ion-header>\r\n");

/***/ }),

/***/ 3006:
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/responsaveis-item/responsaveis-item.component.html ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-item-sliding #sliding>\r\n\r\n  <ion-item>{{ responsaveis.nome | titlecase }}</ion-item>\r\n\r\n  <ion-item-options side='start'>\r\n    <ion-item-option\r\n      color='danger'\r\n      (click)='delete.emit(responsaveis); sliding.close()'\r\n    >\r\n      <ion-icon\r\n        slot='icon-only'\r\n        name='trash'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n\r\n  <ion-item-options side='end'>\r\n    <ion-item-option (click)=\"update.emit(responsaveis); sliding.close()\">\r\n      <ion-icon\r\n        slot=\"icon-only\"\r\n        name='create'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n\r\n</ion-item-sliding>\r\n");

/***/ }),

/***/ 21905:
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/segment-button/segment-button.component.html ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-segment\r\n  mode='md'\r\n  scrollable\r\n  value=\"heart\"\r\n  class='ion-padding'\r\n  style='padding-bottom: 0.5rem'\r\n  (ionChange)=\"segmentChanged($event)\"\r\n  [value]=\"fase\"\r\n  *ngFor='let conta of contador'\r\n>\r\n  <ion-segment-button\r\n    value='home'\r\n    id='segment-home'\r\n  >\r\n    <ion-icon name=\"home\"></ion-icon>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"create\"\r\n    id='segment-create'\r\n  >\r\n    <ion-tab-button class='create'>\r\n      <ion-icon\r\n        color='primary'\r\n        name=\"add-circle-outline\"\r\n      ></ion-icon>\r\n      <ion-label>Novo</ion-label>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"hoje\"\r\n    id='segment-hoje'\r\n  >\r\n    <ion-tab-button class='hoje'>\r\n      <ion-icon\r\n        color='primary'\r\n        name=\"calendar\"\r\n      ></ion-icon>\r\n      <ion-label>Hoje</ion-label>\r\n      <ion-badge>{{ conta.hoje }}</ion-badge>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"abertos\"\r\n    id='segment-programados'\r\n  >\r\n    <ion-tab-button class='programados'>\r\n      <ion-icon\r\n        color='success'\r\n        name=\"file-tray-full-outline\"\r\n      ></ion-icon>\r\n      <ion-label>Abertos</ion-label>\r\n      <ion-badge>{{ conta.abertos }}</ion-badge>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"vencidos\"\r\n    id='segment-vencidos'\r\n  >\r\n    <ion-tab-button class='vencidos'>\r\n      <ion-icon\r\n        color='danger'\r\n        name=\"hourglass-outline\"\r\n      ></ion-icon>\r\n      <ion-label>Vencidos</ion-label>\r\n      <ion-badge>{{ conta.vencidos }}</ion-badge>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"sinalizados\"\r\n    id='segment-sinalizados'\r\n  >\r\n    <ion-tab-button class='sinalizados'>\r\n      <ion-icon\r\n        color='warning'\r\n        name=\"flag-outline\"\r\n      ></ion-icon>\r\n      <ion-label>Sinalizados</ion-label>\r\n      <ion-badge>{{ conta.sinalizados }}</ion-badge>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"finalizados\"\r\n    id='segment-finalizados'\r\n  >\r\n    <ion-tab-button class='check'>\r\n      <ion-icon\r\n        color='primary'\r\n        name=\"checkmark-circle-outline\"\r\n      ></ion-icon>\r\n      <ion-label>Finalizados</ion-label>\r\n      <ion-badge>{{ conta.finalizados }}</ion-badge>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n  <ion-segment-button\r\n    value=\"todos\"\r\n    id='segment-todos'\r\n  >\r\n    <ion-tab-button class='todos'>\r\n      <ion-icon name=\"archive-outline\"></ion-icon>\r\n      <ion-label>Todos</ion-label>\r\n      <ion-badge>{{ conta.todos }}</ion-badge>\r\n    </ion-tab-button>\r\n  </ion-segment-button>\r\n\r\n</ion-segment>\r\n");

/***/ }),

/***/ 82546:
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/task-item/task-item.component.html ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-item-sliding #sliding>\r\n\r\n  <ion-item [@slideInOut]=\"isOpen ? 'in' : 'out'\">\r\n\r\n    <ion-row>\r\n      <ion-col\r\n        size='12'\r\n        class='padding-right-1'\r\n      >\r\n        <ion-icon\r\n          name=\"flag-sharp\"\r\n          color='warning padding-right-05'\r\n          *ngIf='task.sinalizado'\r\n        ></ion-icon>\r\n        <ion-badge [color]='color'>{{ tipo | titlecase }}</ion-badge>\r\n      </ion-col>\r\n\r\n      <ion-col size='12'>\r\n\r\n        <ion-text class='size90'>\r\n          {{ task.title }}\r\n          <div class=\"d-flex justify-content-start\">\r\n            <div *ngFor='let responsavel of task.responsavel'>\r\n              <div style='margin-right: 0.5rem; margin-top:0.3rem'>\r\n                <ion-badge color='medium'>{{ responsavel | titlecase }}</ion-badge>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </ion-text>\r\n        <ion-row class='ion-justify-content-between'>\r\n          <ion-label>\r\n            <p class='size80'>{{ task.data | date: 'd/M/y H:m' }}</p>\r\n          </ion-label>\r\n        </ion-row>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n\r\n    <ion-toggle\r\n      slot='start'\r\n      color='primary'\r\n      [checked]='task.done'\r\n      (ionChange)='done.emit(task); onToggle()'\r\n      (click)='$event.stopPropagation()'\r\n    ></ion-toggle>\r\n    <ion-note\r\n      slot=\"end\"\r\n      class='pointer'\r\n      (click)='update.emit(task)'\r\n    >\r\n      <ion-icon\r\n        class='icon'\r\n        name=\"information-circle-sharp\"\r\n      ></ion-icon>\r\n    </ion-note>\r\n  </ion-item>\r\n\r\n  <ion-item-options side='start'>\r\n    <ion-item-option\r\n      color='danger'\r\n      (click)='onDelete(task); sliding.close()'\r\n    >\r\n      <ion-icon\r\n        slot='icon-only'\r\n        name='trash'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n    <ion-item-option\r\n      color='warning'\r\n      (click)='sinalizada.emit(task); sliding.close();'\r\n    >\r\n      <ion-icon\r\n        slot='icon-only'\r\n        style='color:white'\r\n        name='flag-sharp'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n\r\n  <ion-item-options side='end'>\r\n    <ion-item-option\r\n      color='success'\r\n      (click)=\"hoje.emit(task); sliding.close()\"\r\n    >\r\n      <ion-icon\r\n        slot=\"icon-only\"\r\n        name='calendar'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n    <ion-item-option (click)=\"update.emit(task); sliding.close()\">\r\n      <ion-icon\r\n        slot=\"icon-only\"\r\n        name='create'\r\n      ></ion-icon>\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n\r\n</ion-item-sliding>\r\n");

/***/ })

}]);
//# sourceMappingURL=default-src_app_shared_components_components_module_ts.js.map