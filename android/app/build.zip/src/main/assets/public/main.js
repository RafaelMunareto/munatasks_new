(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/guards/auth.guard */ 27574);




const routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_auth_auth_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/auth/auth.module */ 6621)).then((m) => m.AuthModule),
    },
    {
        path: 'tasks',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_components_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_dashboard_dashboard_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/dashboard/dashboard.module */ 71659)).then((m) => m.DashboardModule),
        canLoad: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
    },
    {
        path: 'responsaveis',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_responsaveis_responsaveis_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/responsaveis/responsaveis.module */ 20950)).then((m) => m.ResponsaveisPageModule),
        canLoad: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
    },
    {
        path: 'etiquetas',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_etiquetas_etiquetas_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/etiquetas/etiquetas.module */ 87376)).then((m) => m.EtiquetasModule),
        canLoad: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules }),
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AppRoutingModule);



/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 91106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 43069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/dashboard/tasks/services/tasks.service */ 42660);
/* harmony import */ var _pages_etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/etiquetas/services/etiquetas.service */ 49144);
/* harmony import */ var _pages_responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/responsaveis/services/responsavel.service */ 35400);











let AppComponent = class AppComponent {
    constructor(authService, etiquetasService, responsavelService, taskServices, store) {
        this.authService = authService;
        this.etiquetasService = etiquetasService;
        this.responsavelService = responsavelService;
        this.taskServices = taskServices;
        this.store = store;
        this.initializeApp();
    }
    initializeApp() {
        this.authService.authState$.subscribe((user) => {
            this.user = user;
            if (user) {
                this.callNgrxGet();
            }
        });
        this.pages = [
            {
                url: '/tasks',
                icon: 'home-outline',
                direction: 'back',
                text: 'Home',
            },
            {
                url: '/responsaveis',
                icon: 'man-outline',
                direction: 'forward',
                text: 'Responsáveis',
            },
            {
                url: '/etiquetas/create',
                icon: 'add-circle-outline',
                direction: 'forward',
                text: 'Nova Etiqueta',
            },
            {
                url: '/responsaveis/create',
                icon: 'add-circle-outline',
                direction: 'forward',
                text: 'Novo Responsável',
            },
            {
                url: '/tasks/create',
                icon: 'add',
                direction: 'forward',
                text: 'Nova Tarefa',
            },
        ];
    }
    callNgrxGet() {
        this.etiquetasService
            .getAll()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.take)(1))
            .subscribe((res) => {
            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddEtiquetas)(res));
        });
        this.taskServices
            .getAll()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.take)(1))
            .subscribe((res) => {
            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddTasks)(res));
        });
        this.responsavelService
            .getAll()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.take)(1))
            .subscribe((res) => {
            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddResponsavel)(res));
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _pages_etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__.EtiquetasService },
    { type: _pages_responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_6__.ResponsavelService },
    { type: _pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_8__.Store }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _pages_responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/responsaveis/services/responsavel.service */ 35400);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/core.module */ 40294);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/platform-browser/animations */ 75835);
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ 17324);
/* harmony import */ var _core_ngrx_reducers_tasks_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core/ngrx/reducers/tasks.reducer */ 88331);
/* harmony import */ var _pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/dashboard/tasks/services/tasks.service */ 42660);
/* harmony import */ var _pages_etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/etiquetas/services/etiquetas.service */ 49144);
/* harmony import */ var _core_ngrx_reducers_etiquetas_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/ngrx/reducers/etiquetas.reducer */ 48760);
/* harmony import */ var _core_ngrx_reducers_responsaveis_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/ngrx/reducers/responsaveis.reducer */ 38684);
/* harmony import */ var _core_ngrx_reducers_selection_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/ngrx/reducers/selection.reducer */ 8493);















let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
        imports: [
            _core_core_module__WEBPACK_IMPORTED_MODULE_3__.CoreModule,
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__.BrowserAnimationsModule,
            _ngrx_store__WEBPACK_IMPORTED_MODULE_14__.StoreModule.forRoot({
                tasks: _core_ngrx_reducers_tasks_reducer__WEBPACK_IMPORTED_MODULE_5__.taskReducer,
                etiquetas: _core_ngrx_reducers_etiquetas_reducer__WEBPACK_IMPORTED_MODULE_8__.etiquetasReducer,
                responsaveis: _core_ngrx_reducers_responsaveis_reducer__WEBPACK_IMPORTED_MODULE_9__.responsaveisReducer,
                selectBox: _core_ngrx_reducers_selection_reducer__WEBPACK_IMPORTED_MODULE_10__.selectionReducer,
            }, {
                runtimeChecks: {
                    strictStateImmutability: false,
                    strictActionImmutability: false,
                },
            }),
        ],
        providers: [
            _pages_dashboard_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_6__.TasksService,
            _pages_etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_7__.EtiquetasService,
            _pages_responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_0__.ResponsavelService,
            _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_4__.LocalNotifications,
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 50536:
/*!*************************************************!*\
  !*** ./src/app/core/classes/firestore.class.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Firestore": () => (/* binding */ Firestore)
/* harmony export */ });
class Firestore {
    constructor(db) {
        this.db = db;
    }
    getAll() {
        return this.collection.valueChanges();
    }
    get(id) {
        return this.collection.doc(id).valueChanges();
    }
    create(item) {
        item.id = this.db.createId();
        return this.setItem(item, 'set');
    }
    update(item) {
        return this.setItem(item, 'update');
    }
    delete(item) {
        return this.collection.doc(item.id).delete();
    }
    setCollection(path, queryFn) {
        this.collection = path ? this.db.collection(path, queryFn) : null;
    }
    setItem(item, operation) {
        return this.collection
            .doc(item.id)[operation](item)
            .then(() => item);
    }
}


/***/ }),

/***/ 40294:
/*!*************************************!*\
  !*** ./src/app/core/core.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoreModule": () => (/* binding */ CoreModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 39075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire */ 50057);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/fire/firestore */ 56717);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/auth */ 49743);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);









let CoreModule = class CoreModule {
};
CoreModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule.forRoot(),
            _angular_fire__WEBPACK_IMPORTED_MODULE_4__.AngularFireModule.initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.firebase),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_5__.AngularFireAuthModule,
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__.AngularFirestoreModule,
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__.AngularFirestoreModule.enablePersistence(),
        ],
        exports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicRouteStrategy }],
    })
], CoreModule);



/***/ }),

/***/ 27574:
/*!*******************************************!*\
  !*** ./src/app/core/guards/auth.guard.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuard": () => (/* binding */ AuthGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 68307);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/auth.service */ 90263);





let AuthGuard = class AuthGuard {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(route, state) {
        return this.checkAuthState(state.url);
    }
    canActivateChild(route, state) {
        return this.canActivate(route, state);
    }
    canLoad(route, segments) {
        const url = segments.map((s) => `/${s}`).join('');
        return this.checkAuthState(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1));
    }
    checkAuthState(redirect) {
        return this.authService.isAuthenticated.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)((is) => {
            if (!is) {
                this.router.navigate(['/login'], {
                    queryParams: { redirect },
                });
            }
        }));
    }
};
AuthGuard.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
AuthGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root',
    })
], AuthGuard);



/***/ }),

/***/ 65221:
/*!***************************************************!*\
  !*** ./src/app/core/ngrx/actions/action-types.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionTypes": () => (/* binding */ ActionTypes),
/* harmony export */   "AddTasks": () => (/* binding */ AddTasks),
/* harmony export */   "RemoveTasks": () => (/* binding */ RemoveTasks),
/* harmony export */   "ClearTasks": () => (/* binding */ ClearTasks),
/* harmony export */   "AddEtiquetas": () => (/* binding */ AddEtiquetas),
/* harmony export */   "RemoveEtiquetas": () => (/* binding */ RemoveEtiquetas),
/* harmony export */   "ClearEtiquetas": () => (/* binding */ ClearEtiquetas),
/* harmony export */   "AddResponsavel": () => (/* binding */ AddResponsavel),
/* harmony export */   "RemoveResponsavel": () => (/* binding */ RemoveResponsavel),
/* harmony export */   "ClearResponsavel": () => (/* binding */ ClearResponsavel),
/* harmony export */   "AddSelectionEtiqueta": () => (/* binding */ AddSelectionEtiqueta),
/* harmony export */   "AddSelectionResponsavel": () => (/* binding */ AddSelectionResponsavel),
/* harmony export */   "AddSelectionFase": () => (/* binding */ AddSelectionFase)
/* harmony export */ });
var ActionTypes;
(function (ActionTypes) {
    //Tasks
    ActionTypes["AddTasks"] = "addTasks";
    ActionTypes["RemoveTasks"] = "remTasks";
    ActionTypes["ClearTasks"] = "clearTasks";
    //Etiquetas
    ActionTypes["AddEtiquetas"] = "addEtiquetas";
    ActionTypes["RemoveEtiquetas"] = "remEtiquetas";
    ActionTypes["ClearEtiquetas"] = "clearEtiquetas";
    //responsavel
    ActionTypes["AddResponsavel"] = "addResponsavel";
    ActionTypes["RemoveResponsavel"] = "remResponsavel";
    ActionTypes["ClearResponsavel"] = "clearResponsavel";
    //selecao
    ActionTypes["AddSelectionEtiqueta"] = "addSelectionEtiqueta";
    ActionTypes["AddSelectionResponsavel"] = "addSelectionResponsavel";
    ActionTypes["AddSelectionFase"] = "addSelectionFase";
})(ActionTypes || (ActionTypes = {}));
//tasks
const AddTasks = (task) => {
    return { type: ActionTypes.AddTasks, payload: task };
};
const RemoveTasks = (task) => {
    return { type: ActionTypes.RemoveTasks, payload: task };
};
const ClearTasks = () => {
    return { type: ActionTypes.ClearTasks, payload: null };
};
//etiquetas
const AddEtiquetas = (etiqueta) => {
    return { type: ActionTypes.AddEtiquetas, payload: etiqueta };
};
const RemoveEtiquetas = (etiqueta) => {
    return { type: ActionTypes.RemoveEtiquetas, payload: etiqueta };
};
const ClearEtiquetas = () => {
    return { type: ActionTypes.ClearEtiquetas, payload: null };
};
//responsavel
const AddResponsavel = (responsavel) => {
    return { type: ActionTypes.AddResponsavel, payload: responsavel };
};
const RemoveResponsavel = (responsavel) => {
    return { type: ActionTypes.RemoveResponsavel, payload: responsavel };
};
const ClearResponsavel = () => {
    return { type: ActionTypes.ClearResponsavel, payload: null };
};
//selction
const AddSelectionEtiqueta = (etiqueta) => {
    return { type: ActionTypes.AddSelectionEtiqueta, payload: etiqueta };
};
const AddSelectionResponsavel = (responsavel) => {
    return {
        type: ActionTypes.AddSelectionResponsavel,
        payload: responsavel,
    };
};
const AddSelectionFase = (fase) => {
    return {
        type: ActionTypes.AddSelectionFase,
        payload: fase,
    };
};


/***/ }),

/***/ 6668:
/*!****************************************************!*\
  !*** ./src/app/core/ngrx/models/completo.model.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompletoModel": () => (/* binding */ CompletoModel)
/* harmony export */ });
class CompletoModel {
    constructor() {
        this.tasks = [];
        this.etiquetas = [];
        this.responsaveis = [];
        this.contador = [];
        this.etiqueta = 'todos';
        this.responsavel = 'todos';
        this.fase = 'todos';
    }
}


/***/ }),

/***/ 48760:
/*!*********************************************************!*\
  !*** ./src/app/core/ngrx/reducers/etiquetas.reducer.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "etiqueta": () => (/* binding */ etiqueta),
/* harmony export */   "etiquetasReducer": () => (/* binding */ etiquetasReducer)
/* harmony export */ });
/* harmony import */ var _actions_action_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../actions/action-types */ 65221);
/* harmony import */ var _models_completo_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/completo.model */ 6668);


const etiqueta = new _models_completo_model__WEBPACK_IMPORTED_MODULE_1__.CompletoModel();
// eslint-disable-next-line prefer-arrow/prefer-arrow-functions
function etiquetasReducer(state = etiqueta, action) {
    switch (action.type) {
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.AddEtiquetas: {
            const idsPayload = action.payload.map((e) => e.id).filter((v) => v);
            return {
                etiquetas: [
                    ...state.etiquetas.filter((e) => !idsPayload.length || !idsPayload.includes(e.id)),
                    ...action.payload,
                ].sort((a, b) => a.nome.localeCompare(b.nome)),
            };
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.RemoveEtiquetas: {
            const etiquetas = state.etiquetas.filter((res) => res.id !== action.payload);
            return Object.assign(Object.assign({}, state), { etiquetas });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.ClearEtiquetas: {
            state = new _models_completo_model__WEBPACK_IMPORTED_MODULE_1__.CompletoModel();
            return state;
        }
        default:
            return state;
    }
}


/***/ }),

/***/ 38684:
/*!************************************************************!*\
  !*** ./src/app/core/ngrx/reducers/responsaveis.reducer.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "responsavel": () => (/* binding */ responsavel),
/* harmony export */   "responsaveisReducer": () => (/* binding */ responsaveisReducer)
/* harmony export */ });
/* harmony import */ var _actions_action_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../actions/action-types */ 65221);
/* harmony import */ var _models_completo_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/completo.model */ 6668);
/* eslint-disable prefer-arrow/prefer-arrow-functions */


const responsavel = new _models_completo_model__WEBPACK_IMPORTED_MODULE_1__.CompletoModel();
function responsaveisReducer(state = responsavel, action) {
    switch (action.type) {
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.AddResponsavel: {
            return Object.assign(Object.assign({}, state), { responsaveis: [...state.responsaveis, ...action.payload] });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.RemoveResponsavel: {
            const responsaveis = state.responsaveis.filter((res) => res.id !== action.payload);
            return Object.assign(Object.assign({}, state), { responsaveis });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.ClearResponsavel: {
            state = new _models_completo_model__WEBPACK_IMPORTED_MODULE_1__.CompletoModel();
            return state;
        }
        default:
            return state;
    }
}


/***/ }),

/***/ 8493:
/*!*********************************************************!*\
  !*** ./src/app/core/ngrx/reducers/selection.reducer.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "select": () => (/* binding */ select),
/* harmony export */   "selectionReducer": () => (/* binding */ selectionReducer)
/* harmony export */ });
/* harmony import */ var src_app_core_ngrx_models_completo_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/ngrx/models/completo.model */ 6668);
/* harmony import */ var _actions_action_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/action-types */ 65221);

/* eslint-disable prefer-arrow/prefer-arrow-functions */

const select = new src_app_core_ngrx_models_completo_model__WEBPACK_IMPORTED_MODULE_0__.CompletoModel();
function selectionReducer(state = select, action) {
    switch (action.type) {
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_1__.ActionTypes.AddSelectionResponsavel: {
            return Object.assign(Object.assign({}, state), { responsavel: action.payload });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_1__.ActionTypes.AddSelectionFase: {
            return Object.assign(Object.assign({}, state), { fase: action.payload });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_1__.ActionTypes.AddSelectionEtiqueta: {
            return Object.assign(Object.assign({}, state), { etiqueta: action.payload });
        }
        default:
            return state;
    }
}


/***/ }),

/***/ 88331:
/*!*****************************************************!*\
  !*** ./src/app/core/ngrx/reducers/tasks.reducer.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "task": () => (/* binding */ task),
/* harmony export */   "taskReducer": () => (/* binding */ taskReducer)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _actions_action_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../actions/action-types */ 65221);
/* harmony import */ var _models_completo_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/completo.model */ 6668);
/* eslint-disable prefer-arrow/prefer-arrow-functions */



const task = new _models_completo_model__WEBPACK_IMPORTED_MODULE_1__.CompletoModel();
function taskReducer(state = task, action) {
    switch (action.type) {
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.AddTasks: {
            const ids = action.payload.map((p) => p.id).filter((v) => v);
            const tasks = [
                ...state.tasks.filter((t) => !ids.length || !ids.includes(t.id)),
                ...action.payload,
            ].sort((a, b) => a.data - b.data);
            const contador = [contadorAction(tasks)];
            const alert = alertAction(tasks);
            return Object.assign(Object.assign({}, state), { contador,
                tasks,
                alert });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.RemoveTasks: {
            const tasks = state.tasks.filter((res) => res.id !== action.payload);
            const contador = [contadorAction(tasks)];
            const alert = [alertAction(tasks)];
            return Object.assign(Object.assign({}, state), { tasks,
                contador,
                alert });
        }
        case _actions_action_types__WEBPACK_IMPORTED_MODULE_0__.ActionTypes.ClearTasks: {
            state = new _models_completo_model__WEBPACK_IMPORTED_MODULE_1__.CompletoModel();
            return state;
        }
        default:
            return state;
    }
    function contadorAction(tasks) {
        const data = (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(new Date(), 'yyyy-MM-dd', 'en');
        const todos = tasks.length.toString();
        const hoje = tasks
            .filter((r) => (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(r.data, 'yyyy-MM-dd', 'en') === data && !r.done)
            .length.toString();
        const vencidos = tasks
            .filter((r) => (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(r.data, 'yyyy-MM-dd', 'en') < data && !r.done)
            .length.toString();
        const abertos = tasks.filter((r) => r.done === false).length.toString();
        const finalizados = tasks.filter((r) => r.done === true).length.toString();
        const sinalizados = tasks
            .filter((r) => r.sinalizado && !r.done)
            .length.toString();
        const resultado = {
            hoje: hoje,
            abertos: abertos,
            sinalizados: sinalizados,
            todos: todos,
            finalizados: finalizados,
            vencidos: vencidos,
        };
        return resultado;
    }
    function alertAction(tasks) {
        const agora = (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(new Date(), "yyyy-MM-dd'T'hh:mm", 'en');
        const timer = (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(new Date().getTime() + 900000, "yyyy-MM-dd'T'hh:mm", 'en');
        const alert = tasks.filter((r) => (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(r.data, "yyyy-MM-dd'T'hh:mm", 'en') > agora &&
            (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.formatDate)(r.data, "yyyy-MM-dd'T'hh:mm", 'en') < timer &&
            !r.done);
        return alert;
    }
}


/***/ }),

/***/ 90263:
/*!***********************************************!*\
  !*** ./src/app/core/services/auth.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/auth */ 49743);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase */ 76797);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 88002);
/* harmony import */ var _auth_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.types */ 71165);






let AuthService = class AuthService {
    constructor(afAuth) {
        this.afAuth = afAuth;
        this.authState$ = this.afAuth.authState;
    }
    get isAuthenticated() {
        return this.authState$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((user) => user !== null));
    }
    authenticate({ isSignIn, provider, user, }) {
        let operation;
        if (provider !== _auth_types__WEBPACK_IMPORTED_MODULE_1__.AuthProvider.Email) {
            operation = this.signInWithPopup(provider);
        }
        else {
            operation = isSignIn
                ? this.signInWithEmail(user)
                : this.signUpWithEmail(user);
        }
        return operation;
    }
    logout() {
        return this.afAuth.signOut();
    }
    sendPasswordResetEmail(email) {
        return new Promise((resolve, reject) => {
            this.afAuth.sendPasswordResetEmail(email).then((data) => {
                resolve(data);
            }, (error) => {
                reject(error);
            });
        });
    }
    signInWithEmail({ email, password, }) {
        return this.afAuth.signInWithEmailAndPassword(email, password);
    }
    signUpWithEmail({ email, password, name, }) {
        return this.afAuth
            .createUserWithEmailAndPassword(email, password)
            .then((credentials) => credentials.user
            .updateProfile({ displayName: name, photoURL: null })
            .then(() => credentials));
    }
    signInWithPopup(provider) {
        let signInProvider = null;
        switch (provider) {
            case _auth_types__WEBPACK_IMPORTED_MODULE_1__.AuthProvider.Facebook:
                signInProvider = new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.FacebookAuthProvider();
                break;
            case _auth_types__WEBPACK_IMPORTED_MODULE_1__.AuthProvider.Google:
                signInProvider = new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.GoogleAuthProvider();
                break;
            case _auth_types__WEBPACK_IMPORTED_MODULE_1__.AuthProvider.Twitter:
                signInProvider = new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.TwitterAuthProvider();
                break;
            case _auth_types__WEBPACK_IMPORTED_MODULE_1__.AuthProvider.Microsoft:
                signInProvider = new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.OAuthProvider('microsoft.com');
                break;
        }
        return this.afAuth.signInWithPopup(signInProvider);
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__.AngularFireAuth }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root',
    })
], AuthService);



/***/ }),

/***/ 71165:
/*!*********************************************!*\
  !*** ./src/app/core/services/auth.types.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthProvider": () => (/* binding */ AuthProvider)
/* harmony export */ });
/* eslint-disable @typescript-eslint/naming-convention */
var AuthProvider;
(function (AuthProvider) {
    AuthProvider[AuthProvider["Email"] = 0] = "Email";
    AuthProvider[AuthProvider["Facebook"] = 1] = "Facebook";
    AuthProvider[AuthProvider["Google"] = 2] = "Google";
    AuthProvider[AuthProvider["Twitter"] = 3] = "Twitter";
    AuthProvider[AuthProvider["Microsoft"] = 4] = "Microsoft";
})(AuthProvider || (AuthProvider = {}));


/***/ }),

/***/ 42660:
/*!*****************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/services/tasks.service.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksService": () => (/* binding */ TasksService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ 56717);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var src_app_core_classes_firestore_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/classes/firestore.class */ 50536);





let TasksService = class TasksService extends src_app_core_classes_firestore_class__WEBPACK_IMPORTED_MODULE_1__.Firestore {
    constructor(authService, db) {
        super(db);
        this.authService = authService;
        this.init();
    }
    init() {
        this.authService.authState$.subscribe((user) => {
            if (user) {
                this.setCollection(`/users/${user.uid}/tasks`, (ref) => ref.orderBy('done', 'asc').orderBy('title', 'asc'));
                this.getAll();
                return;
            }
            this.setCollection(null);
        });
    }
};
TasksService.ctorParameters = () => [
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.AngularFirestore }
];
TasksService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root',
    })
], TasksService);



/***/ }),

/***/ 49144:
/*!***************************************************************!*\
  !*** ./src/app/pages/etiquetas/services/etiquetas.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetasService": () => (/* binding */ EtiquetasService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ 56717);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var src_app_core_classes_firestore_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/classes/firestore.class */ 50536);





let EtiquetasService = class EtiquetasService extends src_app_core_classes_firestore_class__WEBPACK_IMPORTED_MODULE_1__.Firestore {
    constructor(authService, db) {
        super(db);
        this.authService = authService;
        this.init();
    }
    init() {
        this.authService.authState$.subscribe((user) => {
            if (user) {
                this.setCollection(`/users/${user.uid}/etiqueta`, (ref) => ref.orderBy('nome', 'asc'));
                return;
            }
            this.setCollection(null);
        });
    }
};
EtiquetasService.ctorParameters = () => [
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.AngularFirestore }
];
EtiquetasService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root',
    })
], EtiquetasService);



/***/ }),

/***/ 35400:
/*!********************************************************************!*\
  !*** ./src/app/pages/responsaveis/services/responsavel.service.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsavelService": () => (/* binding */ ResponsavelService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ 56717);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var src_app_core_classes_firestore_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/classes/firestore.class */ 50536);





let ResponsavelService = class ResponsavelService extends src_app_core_classes_firestore_class__WEBPACK_IMPORTED_MODULE_1__.Firestore {
    constructor(authService, db) {
        super(db);
        this.authService = authService;
        this.init();
    }
    init() {
        this.authService.authState$.subscribe((user) => {
            if (user) {
                this.setCollection(`/users/${user.uid}/responsavel`, (ref) => ref.orderBy('nome', 'asc'));
                return;
            }
            this.setCollection(null);
        });
    }
};
ResponsavelService.ctorParameters = () => [
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.AngularFirestore }
];
ResponsavelService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root',
    })
], ResponsavelService);



/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    firebase: {
        apiKey: 'AIzaSyDrH51s2tYu3VWHri28tW02WeV6EinPY0w',
        authDomain: 'myapp-b3f48.firebaseapp.com',
        projectId: 'myapp-b3f48',
        storageBucket: 'myapp-b3f48.appspot.com',
        messagingSenderId: '1071081707125',
        appId: '1:1071081707125:web:70c156247242348e974a3c',
        measurementId: 'G-SFSF3J9CE7',
    },
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 24608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		47321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		36108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		31489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		10305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		15830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		37757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		30392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		66911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		30937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		78695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		2239,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		68837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		34195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		41709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		33087,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		84513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		58056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		10862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		76272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		71855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		38708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		23527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		24694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		19222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		25277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		39921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		83122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		51602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		76164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		20592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		27162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		81374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		97896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		25043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		77802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		29072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		32191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		40801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		67110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		10431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 43069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 91106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-split-pane\r\n  contentId='menu-content'\r\n  when='md'\r\n>\r\n  <ion-menu\r\n    contentId='menu-content'\r\n    menuId='main-menu'\r\n    [disabled]='true'\r\n  >\r\n    <ion-header>\r\n      <ion-toolbar color='warning'>\r\n        <ion-title>Menu</ion-title>\r\n      </ion-toolbar>\r\n    </ion-header>\r\n\r\n    <ion-content>\r\n      <ion-menu-toggle autoHide='false'>\r\n        <ion-list>\r\n\r\n          <ion-chip class='ion-margin-start'>\r\n            <ion-avatar>\r\n              <img src=\"assets/avatar.svg\">\r\n            </ion-avatar>\r\n            <ion-label *ngIf='user'>{{ user.displayName }}</ion-label>\r\n          </ion-chip>\r\n\r\n          <ion-item\r\n            button\r\n            *ngFor='let page of pages'\r\n            [routerLink]=\"page.url\"\r\n            [routerDirection]=\"page.direction\"\r\n          >\r\n            <ion-icon\r\n              slot=\"start\"\r\n              [name]=\"page.icon\"\r\n            ></ion-icon>\r\n            <ion-label>{{ page.text }}</ion-label>\r\n          </ion-item>\r\n        </ion-list>\r\n      </ion-menu-toggle>\r\n    </ion-content>\r\n  </ion-menu>\r\n  <ion-router-outlet id='menu-content'></ion-router-outlet>\r\n \r\n</ion-split-pane>\r\n");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map