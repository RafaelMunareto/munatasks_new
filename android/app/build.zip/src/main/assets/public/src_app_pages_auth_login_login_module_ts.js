(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_auth_login_login_module_ts"],{

/***/ 21598:
/*!*************************************************************************!*\
  !*** ./node_modules/capacitor-native-biometric/dist/esm/definitions.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometryType": () => (/* binding */ BiometryType)
/* harmony export */ });
var BiometryType;
(function (BiometryType) {
    BiometryType[BiometryType["NONE"] = 0] = "NONE";
    BiometryType[BiometryType["TOUCH_ID"] = 1] = "TOUCH_ID";
    BiometryType[BiometryType["FACE_ID"] = 2] = "FACE_ID";
    BiometryType[BiometryType["FINGERPRINT"] = 3] = "FINGERPRINT";
    BiometryType[BiometryType["FACE_AUTHENTICATION"] = 4] = "FACE_AUTHENTICATION";
    BiometryType[BiometryType["IRIS_AUTHENTICATION"] = 5] = "IRIS_AUTHENTICATION";
})(BiometryType || (BiometryType = {}));
//# sourceMappingURL=definitions.js.map

/***/ }),

/***/ 37111:
/*!*******************************************************************!*\
  !*** ./node_modules/capacitor-native-biometric/dist/esm/index.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometryType": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.BiometryType),
/* harmony export */   "NativeBiometric": () => (/* binding */ NativeBiometric)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 32275);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 21598);

const NativeBiometric = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('NativeBiometric', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor-native-biometric_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 39763)).then(m => new m.NativeBiometricWeb()),
});


//# sourceMappingURL=index.js.map

/***/ }),

/***/ 32275:
/*!********************************************************************************************!*\
  !*** ./node_modules/capacitor-native-biometric/node_modules/@capacitor/core/dist/index.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Capacitor": () => (/* binding */ Capacitor),
/* harmony export */   "CapacitorException": () => (/* binding */ CapacitorException),
/* harmony export */   "CapacitorPlatforms": () => (/* binding */ CapacitorPlatforms),
/* harmony export */   "ExceptionCode": () => (/* binding */ ExceptionCode),
/* harmony export */   "Plugins": () => (/* binding */ Plugins),
/* harmony export */   "WebPlugin": () => (/* binding */ WebPlugin),
/* harmony export */   "WebView": () => (/* binding */ WebView),
/* harmony export */   "addPlatform": () => (/* binding */ addPlatform),
/* harmony export */   "registerPlugin": () => (/* binding */ registerPlugin),
/* harmony export */   "registerWebPlugin": () => (/* binding */ registerWebPlugin),
/* harmony export */   "setPlatform": () => (/* binding */ setPlatform)
/* harmony export */ });
/*! Capacitor: https://capacitorjs.com/ - MIT License */
const createCapacitorPlatforms = (win) => {
    const defaultPlatformMap = new Map();
    defaultPlatformMap.set('web', { name: 'web' });
    const capPlatforms = win.CapacitorPlatforms || {
        currentPlatform: { name: 'web' },
        platforms: defaultPlatformMap,
    };
    const addPlatform = (name, platform) => {
        capPlatforms.platforms.set(name, platform);
    };
    const setPlatform = (name) => {
        if (capPlatforms.platforms.has(name)) {
            capPlatforms.currentPlatform = capPlatforms.platforms.get(name);
        }
    };
    capPlatforms.addPlatform = addPlatform;
    capPlatforms.setPlatform = setPlatform;
    return capPlatforms;
};
const initPlatforms = (win) => (win.CapacitorPlatforms = createCapacitorPlatforms(win));
const CapacitorPlatforms = /*#__PURE__*/ initPlatforms((typeof globalThis !== 'undefined'
    ? globalThis
    : typeof self !== 'undefined'
        ? self
        : typeof window !== 'undefined'
            ? window
            : typeof global !== 'undefined'
                ? global
                : {}));
const addPlatform = CapacitorPlatforms.addPlatform;
const setPlatform = CapacitorPlatforms.setPlatform;

const legacyRegisterWebPlugin = (cap, webPlugin) => {
    var _a;
    const config = webPlugin.config;
    const Plugins = cap.Plugins;
    if (!config || !config.name) {
        // TODO: add link to upgrade guide
        throw new Error(`Capacitor WebPlugin is using the deprecated "registerWebPlugin()" function, but without the config. Please use "registerPlugin()" instead to register this web plugin."`);
    }
    // TODO: add link to upgrade guide
    console.warn(`Capacitor plugin "${config.name}" is using the deprecated "registerWebPlugin()" function`);
    if (!Plugins[config.name] || ((_a = config === null || config === void 0 ? void 0 : config.platforms) === null || _a === void 0 ? void 0 : _a.includes(cap.getPlatform()))) {
        // Add the web plugin into the plugins registry if there already isn't
        // an existing one. If it doesn't already exist, that means
        // there's no existing native implementation for it.
        // - OR -
        // If we already have a plugin registered (meaning it was defined in the native layer),
        // then we should only overwrite it if the corresponding web plugin activates on
        // a certain platform. For example: Geolocation uses the WebPlugin on Android but not iOS
        Plugins[config.name] = webPlugin;
    }
};

var ExceptionCode;
(function (ExceptionCode) {
    /**
     * API is not implemented.
     *
     * This usually means the API can't be used because it is not implemented for
     * the current platform.
     */
    ExceptionCode["Unimplemented"] = "UNIMPLEMENTED";
    /**
     * API is not available.
     *
     * This means the API can't be used right now because:
     *   - it is currently missing a prerequisite, such as network connectivity
     *   - it requires a particular platform or browser version
     */
    ExceptionCode["Unavailable"] = "UNAVAILABLE";
})(ExceptionCode || (ExceptionCode = {}));
class CapacitorException extends Error {
    constructor(message, code) {
        super(message);
        this.message = message;
        this.code = code;
    }
}
const getPlatformId = (win) => {
    var _a, _b;
    if (win === null || win === void 0 ? void 0 : win.androidBridge) {
        return 'android';
    }
    else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
        return 'ios';
    }
    else {
        return 'web';
    }
};

const createCapacitor = (win) => {
    var _a, _b, _c, _d, _e;
    const cap = win.Capacitor || {};
    const Plugins = (cap.Plugins = cap.Plugins || {});
    const capPlatforms = win.CapacitorPlatforms;
    const defaultGetPlatform = () => getPlatformId(win);
    const getPlatform = ((_a = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _a === void 0 ? void 0 : _a.getPlatform) || defaultGetPlatform;
    const defaultIsNativePlatform = () => getPlatformId(win) !== 'web';
    const isNativePlatform = ((_b = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _b === void 0 ? void 0 : _b.isNativePlatform) || defaultIsNativePlatform;
    const defaultIsPluginAvailable = (pluginName) => {
        const plugin = registeredPlugins.get(pluginName);
        if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
            // JS implementation available for the current platform.
            return true;
        }
        if (getPluginHeader(pluginName)) {
            // Native implementation available.
            return true;
        }
        return false;
    };
    const isPluginAvailable = ((_c = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _c === void 0 ? void 0 : _c.isPluginAvailable) ||
        defaultIsPluginAvailable;
    const defaultGetPluginHeader = (pluginName) => { var _a; return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find(h => h.name === pluginName); };
    const getPluginHeader = ((_d = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _d === void 0 ? void 0 : _d.getPluginHeader) || defaultGetPluginHeader;
    const handleError = (err) => win.console.error(err);
    const pluginMethodNoop = (_target, prop, pluginName) => {
        return Promise.reject(`${pluginName} does not have an implementation of "${prop}".`);
    };
    const registeredPlugins = new Map();
    const defaultRegisterPlugin = (pluginName, jsImplementations = {}) => {
        const registeredPlugin = registeredPlugins.get(pluginName);
        if (registeredPlugin) {
            console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
            return registeredPlugin.proxy;
        }
        const platform = getPlatform();
        const pluginHeader = getPluginHeader(pluginName);
        let jsImplementation;
        const loadPluginImplementation = async () => {
            if (!jsImplementation && platform in jsImplementations) {
                jsImplementation =
                    typeof jsImplementations[platform] === 'function'
                        ? (jsImplementation = await jsImplementations[platform]())
                        : (jsImplementation = jsImplementations[platform]);
            }
            return jsImplementation;
        };
        const createPluginMethod = (impl, prop) => {
            var _a, _b;
            if (pluginHeader) {
                const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find(m => prop === m.name);
                if (methodHeader) {
                    if (methodHeader.rtype === 'promise') {
                        return (options) => cap.nativePromise(pluginName, prop.toString(), options);
                    }
                    else {
                        return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
                    }
                }
                else if (impl) {
                    return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
                }
            }
            else if (impl) {
                return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
            }
            else {
                throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
            }
        };
        const createPluginMethodWrapper = (prop) => {
            let remove;
            const wrapper = (...args) => {
                const p = loadPluginImplementation().then(impl => {
                    const fn = createPluginMethod(impl, prop);
                    if (fn) {
                        const p = fn(...args);
                        remove = p === null || p === void 0 ? void 0 : p.remove;
                        return p;
                    }
                    else {
                        throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
                    }
                });
                if (prop === 'addListener') {
                    p.remove = async () => remove();
                }
                return p;
            };
            // Some flair ✨
            wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
            Object.defineProperty(wrapper, 'name', {
                value: prop,
                writable: false,
                configurable: false,
            });
            return wrapper;
        };
        const addListener = createPluginMethodWrapper('addListener');
        const removeListener = createPluginMethodWrapper('removeListener');
        const addListenerNative = (eventName, callback) => {
            const call = addListener({ eventName }, callback);
            const remove = async () => {
                const callbackId = await call;
                removeListener({
                    eventName,
                    callbackId,
                }, callback);
            };
            const p = new Promise(resolve => call.then(() => resolve({ remove })));
            p.remove = async () => {
                console.warn(`Using addListener() without 'await' is deprecated.`);
                await remove();
            };
            return p;
        };
        const proxy = new Proxy({}, {
            get(_, prop) {
                switch (prop) {
                    // https://github.com/facebook/react/issues/20030
                    case '$$typeof':
                        return undefined;
                    case 'addListener':
                        return pluginHeader ? addListenerNative : addListener;
                    case 'removeListener':
                        return removeListener;
                    default:
                        return createPluginMethodWrapper(prop);
                }
            },
        });
        Plugins[pluginName] = proxy;
        registeredPlugins.set(pluginName, {
            name: pluginName,
            proxy,
            platforms: new Set([
                ...Object.keys(jsImplementations),
                ...(pluginHeader ? [platform] : []),
            ]),
        });
        return proxy;
    };
    const registerPlugin = ((_e = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _e === void 0 ? void 0 : _e.registerPlugin) || defaultRegisterPlugin;
    // Add in convertFileSrc for web, it will already be available in native context
    if (!cap.convertFileSrc) {
        cap.convertFileSrc = filePath => filePath;
    }
    cap.getPlatform = getPlatform;
    cap.handleError = handleError;
    cap.isNativePlatform = isNativePlatform;
    cap.isPluginAvailable = isPluginAvailable;
    cap.pluginMethodNoop = pluginMethodNoop;
    cap.registerPlugin = registerPlugin;
    cap.Exception = CapacitorException;
    cap.DEBUG = !!cap.DEBUG;
    cap.isLoggingEnabled = !!cap.isLoggingEnabled;
    // Deprecated props
    cap.platform = cap.getPlatform();
    cap.isNative = cap.isNativePlatform();
    return cap;
};
const initCapacitorGlobal = (win) => (win.Capacitor = createCapacitor(win));

const Capacitor = /*#__PURE__*/ initCapacitorGlobal(typeof globalThis !== 'undefined'
    ? globalThis
    : typeof self !== 'undefined'
        ? self
        : typeof window !== 'undefined'
            ? window
            : typeof global !== 'undefined'
                ? global
                : {});
const registerPlugin = Capacitor.registerPlugin;
/**
 * @deprecated Provided for backwards compatibility for Capacitor v2 plugins.
 * Capacitor v3 plugins should import the plugin directly. This "Plugins"
 * export is deprecated in v3, and will be removed in v4.
 */
const Plugins = Capacitor.Plugins;
/**
 * Provided for backwards compatibility. Use the registerPlugin() API
 * instead, and provide the web plugin as the "web" implmenetation.
 * For example
 *
 * export const Example = registerPlugin('Example', {
 *   web: () => import('./web').then(m => new m.Example())
 * })
 *
 * @deprecated Deprecated in v3, will be removed from v4.
 */
const registerWebPlugin = (plugin) => legacyRegisterWebPlugin(Capacitor, plugin);

/**
 * Base class web plugins should extend.
 */
class WebPlugin {
    constructor(config) {
        this.listeners = {};
        this.windowListeners = {};
        if (config) {
            // TODO: add link to upgrade guide
            console.warn(`Capacitor WebPlugin "${config.name}" config object was deprecated in v3 and will be removed in v4.`);
            this.config = config;
        }
    }
    addListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
            this.listeners[eventName] = [];
        }
        this.listeners[eventName].push(listenerFunc);
        // If we haven't added a window listener for this event and it requires one,
        // go ahead and add it
        const windowListener = this.windowListeners[eventName];
        if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
        }
        const remove = async () => this.removeListener(eventName, listenerFunc);
        const p = Promise.resolve({ remove });
        Object.defineProperty(p, 'remove', {
            value: async () => {
                console.warn(`Using addListener() without 'await' is deprecated.`);
                await remove();
            },
        });
        return p;
    }
    async removeAllListeners() {
        this.listeners = {};
        for (const listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
        }
        this.windowListeners = {};
    }
    notifyListeners(eventName, data) {
        const listeners = this.listeners[eventName];
        if (listeners) {
            listeners.forEach(listener => listener(data));
        }
    }
    hasListeners(eventName) {
        return !!this.listeners[eventName].length;
    }
    registerWindowListener(windowEventName, pluginEventName) {
        this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName,
            pluginEventName,
            handler: event => {
                this.notifyListeners(pluginEventName, event);
            },
        };
    }
    unimplemented(msg = 'not implemented') {
        return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
    }
    unavailable(msg = 'not available') {
        return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
    }
    async removeListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
            return;
        }
        const index = listeners.indexOf(listenerFunc);
        this.listeners[eventName].splice(index, 1);
        // If there are no more listeners for this type of event,
        // remove the window listener
        if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
        }
    }
    addWindowListener(handle) {
        window.addEventListener(handle.windowEventName, handle.handler);
        handle.registered = true;
    }
    removeWindowListener(handle) {
        if (!handle) {
            return;
        }
        window.removeEventListener(handle.windowEventName, handle.handler);
        handle.registered = false;
    }
}

const WebView = /*#__PURE__*/ registerPlugin('WebView');


//# sourceMappingURL=index.js.map


/***/ }),

/***/ 70792:
/*!**********************************************************!*\
  !*** ./src/app/pages/auth/login/login-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 47412);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 79456:
/*!**************************************************!*\
  !*** ./src/app/pages/auth/login/login.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login-routing.module */ 70792);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page */ 47412);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);






let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _login_routing_module__WEBPACK_IMPORTED_MODULE_1__.LoginPageRoutingModule, src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__.ComponentsModule],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_2__.LoginPage],
    })
], LoginPageModule);



/***/ }),

/***/ 47412:
/*!************************************************!*\
  !*** ./src/app/pages/auth/login/login.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login.page.html */ 32898);
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss */ 66934);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! capacitor-native-biometric */ 37111);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var src_app_core_services_auth_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/auth.types */ 71165);
/* harmony import */ var src_app_shared_validators_validate_password_validator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/validators/validate-password.validator */ 51220);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/services/overlay.service */ 96994);



/* eslint-disable @typescript-eslint/no-unused-expressions */









let LoginPage = class LoginPage {
    constructor(fb, authService, navCtrl, activeRoute, overlayService) {
        this.fb = fb;
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.activeRoute = activeRoute;
        this.overlayService = overlayService;
        this.authProviders = src_app_core_services_auth_types__WEBPACK_IMPORTED_MODULE_4__.AuthProvider;
        this.digitalChange = false;
        this.configs = {
            isSignIn: true,
            action: 'Login',
            actionChange: 'Cadastro',
        };
        this.nameControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(3),
        ]);
        this.confirmPasswordControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(6),
            (0,src_app_shared_validators_validate_password_validator__WEBPACK_IMPORTED_MODULE_5__.mustMatch)('password'),
        ]);
    }
    ngOnInit() {
        this.createForm();
        const redirect = this.activeRoute.snapshot.queryParamMap.get('redirect');
    }
    get email() {
        return this.authForm.get('email');
    }
    get password() {
        return this.authForm.get('password');
    }
    get name() {
        return this.authForm.get('name');
    }
    get confirmPassword() {
        return this.authForm.get('confirmPassword');
    }
    changeAuthAction() {
        this.configs.isSignIn = !this.configs.isSignIn;
        const { isSignIn } = this.configs;
        this.configs.action = isSignIn ? 'Login' : 'Cadastro';
        this.configs.actionChange = isSignIn
            ? 'Crie uma conta'
            : 'Já possuo uma conta';
        if (!isSignIn) {
            this.authForm.addControl('name', this.nameControl);
            this.authForm.addControl('confirmPassword', this.confirmPasswordControl);
        }
        else {
            this.authForm.removeControl('name');
            this.authForm.removeControl('confirmPassword');
        }
    }
    onSubmit(provider) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.overlayService.loading();
            try {
                const credentials = yield this.authService.authenticate({
                    isSignIn: this.configs.isSignIn,
                    user: this.authForm.value,
                    provider,
                });
                this.navCtrl.navigateForward(this.activeRoute.snapshot.queryParamMap.get('redirect') || '/tasks');
            }
            catch (e) {
                yield this.overlayService.toast({
                    message: e.message,
                });
            }
            finally {
                loading.dismiss();
            }
        });
    }
    setCredential(event) {
        this.digitalChange = event.detail.checked;
        capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.setCredentials({
            username: this.authForm.get('email').value,
            password: this.authForm.get('password').value,
            server: 'http://www.munatasks.com',
        }).then().finally(() => this.digitalChange = true);
    }
    deleteCredential() {
        capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.deleteCredentials({
            server: 'http://www.munatasks.com',
        }).then(() => {
            this.overlayService.toast({
                message: 'Login e senha deletados!',
            });
        });
    }
    checkCredential(provider) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.overlayService.loading();
            capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.isAvailable().then((result) => {
                const isAvailable = result.isAvailable;
                const isFaceId = result.biometryType === capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_2__.BiometryType.FACE_ID;
                if (isAvailable) {
                    capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.getCredentials({
                        server: 'http://www.munatasks.com',
                    }).then((credentials) => {
                        console.log(credentials.username);
                        this.authService.authenticate({
                            isSignIn: this.configs.isSignIn,
                            user: { email: credentials.username, password: credentials.password },
                            provider,
                        });
                        this.navCtrl.navigateForward(this.activeRoute.snapshot.queryParamMap.get('redirect') || '/tasks');
                    }).catch((err) => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
                        yield this.overlayService.toast({
                            message: err.message,
                        });
                    }));
                }
            }).finally(() => loading.dismiss());
        });
    }
    createForm() {
        this.authForm = this.fb.group({
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.email]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(6)]],
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_6__.OverlayService }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LoginPage);



/***/ }),

/***/ 51220:
/*!******************************************************************!*\
  !*** ./src/app/shared/validators/validate-password.validator.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mustMatch": () => (/* binding */ mustMatch)
/* harmony export */ });
function mustMatch(otherControlName) {
    let thisControl;
    let otherControl;
    return function matchOtherValidate(control) {
        if (!control.parent) {
            return null;
        }
        // Initializing the validator.
        if (!thisControl) {
            thisControl = control;
            otherControl = control.parent.get(otherControlName);
            if (!otherControl) {
                throw new Error('matchOtherValidator(): other control is not found in parent group');
            }
            otherControl.valueChanges.subscribe(() => {
                thisControl.updateValueAndValidity();
            });
        }
        if (!otherControl) {
            return null;
        }
        if (otherControl.value !== thisControl.value) {
            return {
                mustMatch: true,
            };
        }
        return null;
    };
}


/***/ }),

/***/ 66934:
/*!**************************************************!*\
  !*** ./src/app/pages/auth/login/login.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".forget-password {\n  font-size: 90%;\n  text-align: right;\n  color: --ion-color-primary !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7RUFDQSxpQkFBQTtFQUNBLHFDQUFBO0FBQ0YiLCJmaWxlIjoibG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvcmdldC1wYXNzd29yZCB7XHJcbiAgZm9udC1zaXplOiA5MCU7XHJcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgY29sb3I6IC0taW9uLWNvbG9yLXByaW1hcnkgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 32898:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/auth/login/login.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content padding>\r\n  <ion-grid>\r\n    <ion-row class='ion-justify-content-center'>\r\n      <ion-col\r\n        size-xs='12'\r\n        size-sm='8'\r\n        size-md='6'\r\n        size-lg='4'\r\n        size-xl='3'\r\n      >\r\n        <div style='display:flex; justify-content: center; padding: 1rem;'>\r\n          <ion-img\r\n            slot='center'\r\n            style='max-width: 50%;'\r\n            src=\"assets/icon/favicon.png\"\r\n          ></ion-img>\r\n        </div>\r\n\r\n        <form\r\n          [formGroup]=\"authForm\"\r\n          class=\"ion-padding\"\r\n          (submit)=\"onSubmit(authProviders.Email)\"\r\n        >\r\n\r\n          <ng-container *ngIf='!configs.isSignIn'>\r\n            <app-input-icon-valild\r\n              ngDefaultControl\r\n              name='name'\r\n              [form]='authForm'\r\n              autocomplete='on'\r\n              [autofocus]='true'\r\n            ></app-input-icon-valild>\r\n          </ng-container>\r\n\r\n          <app-input-icon-valild\r\n            ngDefaultControl\r\n            name='email'\r\n            [form]='authForm'\r\n            autocomplete='on'\r\n            [autofocus]='true'\r\n          ></app-input-icon-valild>\r\n\r\n          <app-input-icon-valild\r\n            ngDefaultControl\r\n            name='password'\r\n            [form]='authForm'\r\n            autocomplete='on'\r\n            [autofocus]='true'\r\n          ></app-input-icon-valild>\r\n\r\n          <ng-container *ngIf='!configs.isSignIn'>\r\n            <app-input-icon-valild\r\n              ngDefaultControl\r\n              name='confirmPassword'\r\n              [form]='authForm'\r\n              [autofocus]='true'\r\n            ></app-input-icon-valild>\r\n          </ng-container>\r\n\r\n          <ion-button\r\n            expand=\"block\"\r\n            type=\"submit\"\r\n            [disabled]=\"authForm.invalid\"\r\n          >\r\n            {{ configs.action }}\r\n          </ion-button>\r\n          <div class=\"d-flex justify-content-end padding-right-05\">\r\n            <ion-text\r\n              slot='end'\r\n              color='primary'\r\n              class='forget-password'\r\n              routerLink=\"password\"\r\n              routerDirection=\"forward\"\r\n            >\r\n              Esqueceu a senha?\r\n            </ion-text>\r\n\r\n          </div>\r\n        </form>\r\n        <ion-button\r\n          expand=\"block\"\r\n          fill=\"clear\"\r\n          class='bold'\r\n          (click)=\"changeAuthAction()\"\r\n        >\r\n          {{ configs.actionChange }}\r\n        </ion-button>\r\n\r\n        <ion-item>\r\n          <ion-label>Cadastrar login e senha para digital</ion-label>\r\n          <ion-toggle (ionChange)=\"setCredential($event)\"></ion-toggle>\r\n        </ion-item>\r\n\r\n        <ion-button (click)=\"checkCredential(authProviders.Email)\"\r\n          expand=\"block\"\r\n          class=\"ion-text-start\"\r\n          color='medium'\r\n        >\r\n        Login com digital\r\n        <ion-icon name=\"finger-print-outline\" slot='start'></ion-icon>\r\n        </ion-button>\r\n\r\n\r\n        <ion-button\r\n        (click)=\"deleteCredential()\"\r\n        expand=\"block\"\r\n        class=\"ion-text-left\"\r\n        color='medium'\r\n        >\r\n        <ion-icon name=\"finger-print-outline\" slot='start'></ion-icon>\r\n\r\n        Deletar login Digital\r\n        </ion-button>\r\n\r\n        <ion-button\r\n          expand=\"block\"\r\n          class=\"ion-text-start\"\r\n          color='primary'\r\n          (click)=\"onSubmit(authProviders.Facebook)\"\r\n        >\r\n          <ion-icon\r\n            name=\"logo-facebook\"\r\n            slot=\"start\"\r\n          ></ion-icon>\r\n          Login com Facebook\r\n        </ion-button>\r\n        <ion-button\r\n          expand=\"block\"\r\n          class=\"ion-text-start\"\r\n          color='danger'\r\n          (click)=\"onSubmit(authProviders.Google)\"\r\n        >\r\n          <ion-icon\r\n            name=\"logo-google\"\r\n            slot=\"start\"\r\n          ></ion-icon>\r\n          Login com Google\r\n        </ion-button>\r\n        <ion-button\r\n          expand=\"block\"\r\n          class=\"ion-text-start\"\r\n          color='secondary'\r\n          (click)=\"onSubmit(authProviders.Twitter)\"\r\n        >\r\n          <ion-icon\r\n            name=\"logo-twitter\"\r\n            slot=\"start\"\r\n          ></ion-icon>\r\n          Login com Twitter\r\n        </ion-button>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_auth_login_login_module_ts.js.map