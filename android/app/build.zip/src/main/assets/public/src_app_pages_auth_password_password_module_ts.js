(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_auth_password_password_module_ts"],{

/***/ 88057:
/*!****************************************************************!*\
  !*** ./src/app/pages/auth/password/password-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasswordPageRoutingModule": () => (/* binding */ PasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./password.page */ 46364);




const routes = [
    {
        path: '',
        component: _password_page__WEBPACK_IMPORTED_MODULE_0__.PasswordPage
    }
];
let PasswordPageRoutingModule = class PasswordPageRoutingModule {
};
PasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PasswordPageRoutingModule);



/***/ }),

/***/ 51524:
/*!********************************************************!*\
  !*** ./src/app/pages/auth/password/password.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasswordPageModule": () => (/* binding */ PasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./password-routing.module */ 88057);
/* harmony import */ var _password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./password.page */ 46364);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);






let PasswordPageModule = class PasswordPageModule {
};
PasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule, _password_routing_module__WEBPACK_IMPORTED_MODULE_0__.PasswordPageRoutingModule],
        declarations: [_password_page__WEBPACK_IMPORTED_MODULE_1__.PasswordPage],
    })
], PasswordPageModule);



/***/ }),

/***/ 46364:
/*!******************************************************!*\
  !*** ./src/app/pages/auth/password/password.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasswordPage": () => (/* binding */ PasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_password_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./password.page.html */ 61774);
/* harmony import */ var _password_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./password.page.scss */ 95362);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/services/overlay.service */ 96994);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/auth.service */ 90263);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);








let PasswordPage = class PasswordPage {
    constructor(navCtrl, loadingCtrl, formBuilder, auth) {
        this.navCtrl = navCtrl;
        this.loadingCtrl = loadingCtrl;
        this.formBuilder = formBuilder;
        this.auth = auth;
        this.form = this.formBuilder.group({
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
        });
    }
    signInWithEmail() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.loading();
            this.auth.sendPasswordResetEmail(this.form.value.email).then(() => {
                loading.dismiss();
                this.hasError = false;
                this.emailSent = true;
            }, (error) => {
                loading.dismiss();
                switch (error.code) {
                    case 'auth/invalid-email':
                        this.errorMessage = 'Insira um email válido.';
                        break;
                    case 'auth/user-not-found':
                        this.errorMessage = 'Nenhum usuário com este email encontrado.';
                        break;
                    default:
                        this.errorMessage = error;
                        break;
                }
                this.hasError = true;
            });
        });
    }
    navigatePop() {
        this.navCtrl.pop();
    }
};
PasswordPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_2__.OverlayService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: src_app_core_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService }
];
PasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-password',
        template: _raw_loader_password_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_password_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PasswordPage);



/***/ }),

/***/ 95362:
/*!********************************************************!*\
  !*** ./src/app/pages/auth/password/password.page.scss ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".primary {\n  color: #3880ff !important;\n}\n\n.footer {\n  background-color: #bfbfbf !important;\n  text-align: center;\n}\n\n.footer-toolbar {\n  background-color: #bfbfbf !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhc3N3b3JkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQ0FBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQ0FBQTtBQUNGIiwiZmlsZSI6InBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcmltYXJ5IHtcclxuICBjb2xvcjogIzM4ODBmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZm9vdGVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYmZiZmJmICFpbXBvcnRhbnQ7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uZm9vdGVyLXRvb2xiYXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNiZmJmYmYgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 61774:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/auth/password/password.page.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot='start'>\r\n      <ion-back-button defaultHref=\"/login\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Esqueceu a senha</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-grid>\r\n    <ion-row class='ion-justify-content-center'>\r\n      <ion-col\r\n        size-xs='12'\r\n        size-sm='8'\r\n        size-md='6'\r\n        size-lg='4'\r\n        size-xl='3'\r\n      >\r\n        <form\r\n          [formGroup]=\"form\"\r\n          (ngSubmit)=\"signInWithEmail()\"\r\n          *ngIf=\"!emailSent\"\r\n        >\r\n          <app-input-icon-valild\r\n            ngDefaultControl\r\n            name='email'\r\n            [form]='form'\r\n            [autofocus]='true'\r\n          ></app-input-icon-valild>\r\n\r\n          <div class=\"justify-content-end\">\r\n            <ion-button\r\n              slot='end'\r\n              color=\"primary bold\"\r\n              fill='clear'\r\n              type=\"submit\"\r\n              [disabled]=\"!form.valid\"\r\n            >\r\n              Enviar email\r\n            </ion-button>\r\n          </div>\r\n        </form>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-row class='ion-justify-content-center'>\r\n    <ion-col\r\n      size-xs='12'\r\n      size-sm='8'\r\n      size-md='6'\r\n      size-lg='4'\r\n      size-xl='3'\r\n    >\r\n\r\n      <ion-card\r\n        class='padding-2'\r\n        *ngIf=\"emailSent\"\r\n      >\r\n\r\n        <ion-card-header>\r\n          <ion-card-title color='success'>SUCESSO!!!</ion-card-title>\r\n        </ion-card-header>\r\n\r\n        <ion-card-content class='padding-2'>\r\n          Em breve você receberá um email para resetar a sua nova senha.\r\n        </ion-card-content>\r\n      </ion-card>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n\r\n<ion-footer\r\n  class=\"footer\"\r\n  (click)=\"navigatePop()\"\r\n>\r\n  <ion-toolbar color='light'>\r\n    <span>\r\n      Já tem uma conta?\r\n      <strong class='bold primary pointer'>Faça login</strong>\r\n    </span>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_auth_password_password_module_ts.js.map