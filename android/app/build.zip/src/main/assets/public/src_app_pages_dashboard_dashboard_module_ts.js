(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_dashboard_dashboard_module_ts"],{

/***/ 99366:
/*!*************************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardRoutingModule": () => (/* binding */ DashboardRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/guards/auth.guard */ 27574);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.component */ 24789);





const routes = [
    {
        path: '',
        component: _dashboard_component__WEBPACK_IMPORTED_MODULE_1__.DashboardComponent,
        canActivateChild: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        children: [
            {
                path: '',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_dashboard_home_home_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 9871)).then((m) => m.HomePageModule),
            },
            {
                path: 'create',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_pages_dashboard_tasks_task-save_task-save_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./tasks/task-save/task-save.module */ 56402)).then((m) => m.TaskSavePageModule),
            },
            {
                path: 'edit/:id',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_pages_dashboard_tasks_task-save_task-save_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./tasks/task-save/task-save.module */ 56402)).then((m) => m.TaskSavePageModule),
            },
            {
                path: 'list',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_pages_dashboard_tasks_tasks-list_tasks-list_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./tasks/tasks-list/tasks-list.module */ 23621)).then((m) => m.TasksListPageModule),
            },
        ],
    },
];
let DashboardRoutingModule = class DashboardRoutingModule {
};
DashboardRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    })
], DashboardRoutingModule);



/***/ }),

/***/ 24789:
/*!********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardComponent": () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./dashboard.component.html */ 6857);
/* harmony import */ var _dashboard_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.component.scss */ 88038);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tasks/services/tasks.service */ 42660);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../etiquetas/services/etiquetas.service */ 49144);
/* harmony import */ var _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../responsaveis/services/responsavel.service */ 35400);









let DashboardComponent = class DashboardComponent {
    constructor(tasksService, etiquetasService, responsaveisService, store) {
        this.tasksService = tasksService;
        this.etiquetasService = etiquetasService;
        this.responsaveisService = responsaveisService;
        this.store = store;
        this.totalTaks = 0;
        this.totalEtiquetas = 0;
        this.totalResponsaveis = 0;
        this.alert = [];
    }
    ionViewDidEnter() {
        //chamada do tasks
        this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_6__.select)('tasks')).subscribe((res) => {
            this.contador = res.contador;
            this.totalTaks = res.tasks.length;
        });
        //condicao para executar o ngrx tem tb no appComponente
        this.tasksService.getAll().subscribe((res) => {
            if (res.length !== this.totalTaks) {
                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.ClearTasks)());
                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddTasks)(res));
            }
        });
        this.etiquetasService.getAll().subscribe((res) => {
            if (res.length !== this.totalEtiquetas) {
                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.ClearEtiquetas)());
                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddEtiquetas)(res));
            }
        });
        this.responsaveisService.getAll().subscribe((res) => {
            if (res.length !== this.totalResponsaveis) {
                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.ClearResponsavel)());
                this.store.dispatch((0,src_app_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_3__.AddResponsavel)(res));
            }
        });
    }
};
DashboardComponent.ctorParameters = () => [
    { type: _tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_2__.TasksService },
    { type: _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__.EtiquetasService },
    { type: _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_5__.ResponsavelService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_6__.Store }
];
DashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        template: _raw_loader_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_dashboard_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DashboardComponent);



/***/ }),

/***/ 71659:
/*!*****************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardModule": () => (/* binding */ DashboardModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 24789);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard-routing.module */ 99366);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../etiquetas/services/etiquetas.service */ 49144);
/* harmony import */ var _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../responsaveis/services/responsavel.service */ 35400);
/* harmony import */ var _tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tasks/services/tasks.service */ 42660);









let DashboardModule = class DashboardModule {
};
DashboardModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [_dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent],
        imports: [_dashboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.DashboardRoutingModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__.ComponentsModule],
        providers: [_tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_6__.TasksService, _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__.EtiquetasService, _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_5__.ResponsavelService],
    })
], DashboardModule);



/***/ }),

/***/ 88038:
/*!**********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.scss ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXNoYm9hcmQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 6857:
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/dashboard.component.html ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-content>\r\n\r\n<app-segment-button [contador]='contador'></app-segment-button>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_dashboard_dashboard_module_ts.js.map