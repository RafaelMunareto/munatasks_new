(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_dashboard_home_home_module_ts"],{

/***/ 32242:
/*!*************************************************************!*\
  !*** ./src/app/pages/dashboard/home/home-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeralRoutingModule": () => (/* binding */ GeralRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 49226);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePageComponent,
    },
];
let GeralRoutingModule = class GeralRoutingModule {
};
GeralRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GeralRoutingModule);



/***/ }),

/***/ 9871:
/*!*****************************************************!*\
  !*** ./src/app/pages/dashboard/home/home.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 32242);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ 49226);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../etiquetas/services/etiquetas.service */ 49144);








let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule, _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.GeralRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_3__.HomePageComponent],
        providers: [_etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__.EtiquetasService],
    })
], HomePageModule);



/***/ }),

/***/ 49226:
/*!***************************************************!*\
  !*** ./src/app/pages/dashboard/home/home.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageComponent": () => (/* binding */ HomePageComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home.page.html */ 60766);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 72834);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../core/services/overlay.service */ 96994);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 88002);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 87519);
/* harmony import */ var _tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../tasks/services/tasks.service */ 42660);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../etiquetas/services/etiquetas.service */ 49144);











let HomePageComponent = class HomePageComponent {
    constructor(tasksService, navCtrl, etiquetasService, overlayService, store) {
        this.tasksService = tasksService;
        this.navCtrl = navCtrl;
        this.etiquetasService = etiquetasService;
        this.overlayService = overlayService;
        this.store = store;
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            setTimeout(() => {
                this.etiquetas$ = this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_7__.select)('etiquetas'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)((res) => res.etiquetas));
                this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_7__.select)('tasks')).subscribe((res) => {
                    this.contador = res.contador;
                });
            }, 700);
        });
    }
    onUpdate(etiqueta) {
        this.navCtrl.navigateForward(['etiquetas', 'edit', etiqueta.id]);
    }
    onDetail(etiqueta) {
        this.navCtrl.navigateForward(['/tasks/list']);
        this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionFase)('todos'));
        setTimeout(() => this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionEtiqueta)(etiqueta.nome)), 10);
    }
    onDirect(event) {
        this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionFase)(event));
        this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionEtiqueta)('todos'));
        this.navCtrl.navigateRoot(['/tasks/list']);
    }
    onDelete(etiqueta) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            yield this.overlayService.alert({
                message: `Tem certeza que deseja excluír a tarefa ${etiqueta.nome} ?`,
                buttons: [
                    {
                        text: 'Sim',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                            yield this.etiquetasService.delete(etiqueta);
                            yield this.overlayService.toast({
                                message: `Etiqueta ${etiqueta.nome} deletada!`,
                            });
                            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.RemoveEtiquetas)(etiqueta.id));
                        }),
                    },
                    'Não',
                ],
            });
        });
    }
    getItems(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const val = ev.target.value;
            if (val && val !== '') {
                this.etiquetas$ = this.etiquetas$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)((res) => res.filter((state) => state.nome.toLowerCase().indexOf(val.toLowerCase()) !== -1)));
            }
        });
    }
};
HomePageComponent.ctorParameters = () => [
    { type: _tasks_services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController },
    { type: _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__.EtiquetasService },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__.OverlayService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_7__.Store }
];
HomePageComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HomePageComponent);



/***/ }),

/***/ 72834:
/*!*****************************************************!*\
  !*** ./src/app/pages/dashboard/home/home.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 60766:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/home/home.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<app-menu-toggle title=\"Home\"></app-menu-toggle>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"(etiquetas$ | async); else skeletonContador\">\r\n    <ion-grid\r\n      class='ion-margin-top ion-margin-bottom'\r\n      *ngFor='let conta of contador'\r\n    >\r\n      <ion-row class='ion-justify-content-center'>\r\n        <app-card-icone-contador\r\n          label='Hoje'\r\n          color='primary'\r\n          icone='calendar-outline'\r\n          (direct)=\"onDirect('hoje')\"\r\n          [data]='conta.hoje'\r\n        ></app-card-icone-contador>\r\n        <app-card-icone-contador\r\n          label='Abertos'\r\n          color='success'\r\n          icone='file-tray-full-outline'\r\n          [data]='conta.abertos'\r\n          (direct)=\"onDirect('abertos')\"\r\n        ></app-card-icone-contador>\r\n      </ion-row>\r\n      <ion-row class='ion-justify-content-center'>\r\n        <app-card-icone-contador\r\n          label='Sinalizados'\r\n          color='warning'\r\n          icone='flag-outline'\r\n          [data]='conta.sinalizados'\r\n          (direct)=\"onDirect('sinalizados')\"\r\n        ></app-card-icone-contador>\r\n        <app-card-icone-contador\r\n          label='Finalizados'\r\n          color='primary'\r\n          icone='checkmark-circle-outline'\r\n          [data]='conta.finalizados'\r\n          (direct)=\"onDirect('finalizados')\"\r\n        ></app-card-icone-contador>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n\r\n  <ng-template #skeletonContador>\r\n    <div class='flex-column padding-top-2'>\r\n      <div class='justify-content-center'>\r\n        <div class=\"custom-skeleton padding-right-1\">\r\n          <ion-skeleton-text\r\n            animated\r\n            style=\"width: 10rem; height:5.5rem; border-radius:10px\"\r\n          ></ion-skeleton-text>\r\n        </div>\r\n        <div class=\"custom-skeleton\">\r\n          <ion-skeleton-text\r\n            animated\r\n            style=\"width: 10rem; height:5.5rem; border-radius:10px\"\r\n          ></ion-skeleton-text>\r\n        </div>\r\n      </div>\r\n      <div class='justify-content-center '>\r\n        <div class=\"custom-skeleton padding-right-1\">\r\n          <ion-skeleton-text\r\n            animated\r\n            style=\"width: 10rem; height:5.5rem; border-radius:10px\"\r\n          ></ion-skeleton-text>\r\n        </div>\r\n        <div class=\"custom-skeleton\">\r\n          <ion-skeleton-text\r\n            animated\r\n            style=\"width: 10rem; height:5.5rem; border-radius:10px\"\r\n          ></ion-skeleton-text>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </ng-template>\r\n\r\n  <ion-grid>\r\n    <ion-row class=\"justify-content-between align-items-baseline\">\r\n      <ion-text color=\"primary\">\r\n        <h1 class='ion-padding-start bold'>Etiquetas</h1>\r\n      </ion-text>\r\n\r\n      <ion-chip\r\n        routerLink=\"/etiquetas/create\"\r\n        routerDirection=\"forward\"\r\n        color=\"primary\"\r\n        class='pointer'\r\n      >\r\n        <ion-icon\r\n          name=\"add-circle-outline\"\r\n          color=\"primary\"\r\n        ></ion-icon>\r\n        <ion-label color='primary'>Nova etiqueta</ion-label>\r\n      </ion-chip>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-toolbar>\r\n    <ion-searchbar\r\n      [(ngModel)]=\"filtro\"\r\n      animated=\"true\"\r\n      mode='ios'\r\n      placeholder='Procurar'\r\n    ></ion-searchbar>\r\n  </ion-toolbar>\r\n\r\n  <ion-list fullscreen>\r\n    <ng-container *ngIf=\"(etiquetas$ | async) as etiquetas; else skeleton\">\r\n\r\n      <div *ngIf=\"etiquetas.length > 0; else noTags\">\r\n        <app-etiqueta-item\r\n          *ngFor=\"let etiqueta of etiquetas | filter: filtro\"\r\n          [etiqueta]=\"etiqueta\"\r\n          (update)=\"onUpdate($event)\"\r\n          (delete)=\"onDelete($event)\"\r\n          (detail)=\"onDetail($event)\"\r\n          class=\"animation\"\r\n        >\r\n        </app-etiqueta-item>\r\n      </div>\r\n    </ng-container>\r\n\r\n    <ng-template #noTags>\r\n      <app-no-tasks msg='Nenhuma etiqueta ainda...'></app-no-tasks>\r\n    </ng-template>\r\n\r\n  </ion-list>\r\n\r\n  <ng-template #skeleton>\r\n    <app-skeleton-list></app-skeleton-list>\r\n  </ng-template>\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_dashboard_home_home_module_ts.js.map