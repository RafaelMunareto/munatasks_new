(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_dashboard_tasks_task-save_task-save_module_ts"],{

/***/ 56310:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/task-save/task-save-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskSavePageRoutingModule": () => (/* binding */ TaskSavePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _task_save_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./task-save.page */ 61003);




const routes = [
    {
        path: '',
        component: _task_save_page__WEBPACK_IMPORTED_MODULE_0__.TaskSavePage
    }
];
let TaskSavePageRoutingModule = class TaskSavePageRoutingModule {
};
TaskSavePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TaskSavePageRoutingModule);



/***/ }),

/***/ 56402:
/*!*********************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/task-save/task-save.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskSavePageModule": () => (/* binding */ TaskSavePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _task_save_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./task-save-routing.module */ 56310);
/* harmony import */ var _task_save_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./task-save.page */ 61003);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var _shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../shared/directives/directives.module */ 35540);
/* harmony import */ var _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../responsaveis/services/responsavel.service */ 35400);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/tasks.service */ 42660);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../etiquetas/services/etiquetas.service */ 49144);











let TaskSavePageModule = class TaskSavePageModule {
};
TaskSavePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
            src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__.ComponentsModule,
            _task_save_routing_module__WEBPACK_IMPORTED_MODULE_0__.TaskSavePageRoutingModule,
            _shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_4__.DirectivesModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule,
        ],
        declarations: [_task_save_page__WEBPACK_IMPORTED_MODULE_1__.TaskSavePage],
        providers: [_services_tasks_service__WEBPACK_IMPORTED_MODULE_6__.TasksService, _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_7__.EtiquetasService, _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_5__.ResponsavelService],
    })
], TaskSavePageModule);



/***/ }),

/***/ 61003:
/*!*******************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/task-save/task-save.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskSavePage": () => (/* binding */ TaskSavePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_task_save_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./task-save.page.html */ 8820);
/* harmony import */ var _task_save_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./task-save.page.scss */ 11392);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ 16738);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/tasks.service */ 42660);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../core/services/overlay.service */ 96994);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../etiquetas/services/etiquetas.service */ 49144);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ 86710);














let TaskSavePage = class TaskSavePage {
    constructor(fb, tasksService, overlayService, route, navCtrl, etiquetaService, store) {
        this.fb = fb;
        this.tasksService = tasksService;
        this.overlayService = overlayService;
        this.route = route;
        this.navCtrl = navCtrl;
        this.etiquetaService = etiquetaService;
        this.store = store;
        this.pageTitle = '...';
        this.taskId = undefined;
        this.pickerShow = false;
        this.hoje = moment__WEBPACK_IMPORTED_MODULE_3__(new Date()).format('YYYY-MM-DDTHH:mmZ');
        this.etiquetas = [];
        this.responsaveis = [];
        this.responsavel = [];
        this.accordionExpanded = false;
        this.isOpen = true;
        this.createForm();
    }
    ionViewDidEnter() {
        this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_7__.select)('responsaveis')).subscribe((res) => {
            this.responsaveis = res.responsaveis;
        });
        this.init();
    }
    init() {
        this.taskId = this.route.snapshot.paramMap.get('id');
        this.etiquetaService
            .getAll()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.take)(1))
            .subscribe((res) => (this.etiquetas = res));
        if (!this.taskId) {
            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionFase)('create'));
            this.pageTitle = 'Criar Tarefa';
            return;
        }
        else {
            this.pageTitle = 'Editar Tarefa';
            this.tasksService
                .get(this.taskId)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.take)(1))
                .subscribe(({ title, done, tipo, data, sinalizado, responsavel }) => {
                this.taskForm.get('title').setValue(title);
                this.taskForm.get('done').setValue(done);
                this.taskForm.get('tipo').setValue(tipo);
                this.taskForm.get('data').setValue(data);
                this.taskForm.get('sinalizado').setValue(sinalizado);
                this.taskForm.get('responsavel').setValue(responsavel);
                this.responsaveisTask = responsavel !== null && responsavel !== void 0 ? responsavel : [];
            });
        }
    }
    onSubmit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.overlayService.loading({
                message: 'Salvando ...',
            });
            try {
                if (this.taskId) {
                    const newTask = yield this.tasksService.update(Object.assign({ id: this.taskId }, this.taskForm.value));
                    this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddTasks)([newTask]));
                    this.navCtrl.back();
                }
                else {
                    const newTask = yield this.tasksService.create(Object.assign({}, this.taskForm.value));
                    this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddTasks)([newTask]));
                    this.navCtrl.navigateBack(`/tasks`);
                }
            }
            catch (error) {
                yield this.overlayService.toast({
                    message: error.message,
                });
            }
            finally {
                loading.dismiss();
            }
        });
    }
    toogle(event, nome) {
        if (event.detail.checked) {
            this.responsavel.push(nome);
        }
        else {
            this.responsavel = this.responsavel.filter((res) => res !== nome);
        }
        this.taskForm.get('responsavel').setValue(this.responsavel);
    }
    povoaChecked(event) {
        var _a;
        return (_a = this.responsaveisTask) === null || _a === void 0 ? void 0 : _a.includes(event);
    }
    hojeAction(event) {
        if (event.detail.checked) {
            this.pickerShow = true;
            this.taskForm.get('data').setValue(this.hoje);
        }
        else {
            this.pickerShow = false;
        }
    }
    get title() {
        return this.taskForm.get('title');
    }
    toggleAccordion(event) {
        this.accordionExpanded = this.accordionExpanded === false;
        if (event.detail.checked === true) {
            this.isOpen = false;
        }
        else {
            this.isOpen = true;
        }
    }
    createForm() {
        this.taskForm = this.fb.group({
            title: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.minLength(3)]],
            tipo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.minLength(3)]],
            data: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required]],
            responsavel: [''],
            done: [false],
            sinalizado: [false],
        });
    }
};
TaskSavePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder },
    { type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_5__.OverlayService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_6__.EtiquetasService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_7__.Store }
];
TaskSavePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        template: _raw_loader_task_save_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_task_save_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TaskSavePage);



/***/ }),

/***/ 11392:
/*!*********************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/task-save/task-save.page.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".select {\n  font-weight: bold;\n  font-size: 120% !important;\n}\n\nitem-native {\n  padding: 0rem !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhc2stc2F2ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBQTtFQUNBLDBCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx3QkFBQTtBQUNGIiwiZmlsZSI6InRhc2stc2F2ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VsZWN0IHtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBmb250LXNpemU6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaXRlbS1uYXRpdmUge1xyXG4gIHBhZGRpbmc6IDByZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuIl19 */");

/***/ }),

/***/ 8820:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/tasks/task-save/task-save.page.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot='start'>\r\n      <ion-back-button defaultHref=\"/tasks\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{ pageTitle }}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <form\r\n    class='ion-padding'\r\n    [formGroup]=\"taskForm\"\r\n    (submit)=\"onSubmit()\"\r\n  >\r\n    <ion-item>\r\n      <ion-textarea\r\n        rows=\"6\"\r\n        name='title'\r\n        placeholder='Lembrete'\r\n        formControlName='title'\r\n      ></ion-textarea>\r\n      <app-validator-note [form-control]=\"$any(taskForm.get('title'))\"></app-validator-note>\r\n      <ion-toggle\r\n        slot='start'\r\n        color='primary'\r\n        formControlName='done'\r\n      ></ion-toggle>\r\n    </ion-item>\r\n\r\n    <ion-row>\r\n      <ion-col size='8'>\r\n        <ion-select\r\n          placeholder=\"Selecione um item\"\r\n          interface=\"action-sheet\"\r\n          okText=\"OK\"\r\n          cancelText=\"Cancelar\"\r\n          class=\"ion-padding select\"\r\n          formControlName='tipo'\r\n          [appTaskTipos]='etiquetas'\r\n        >\r\n          <ion-select-option\r\n            *ngFor='let etiqueta of etiquetas'\r\n            value=\"{{ etiqueta.nome }}\"\r\n          >\r\n            <ion-text>\r\n\r\n              <ion-badge [color]='etiqueta.cor'>{{ etiqueta.nome | titlecase }}</ion-badge>\r\n            </ion-text>\r\n          </ion-select-option>\r\n        </ion-select>\r\n      </ion-col>\r\n      <ion-col\r\n        size='4'\r\n        class='align-items-center justify-content-center'\r\n      >\r\n        <ion-label>\r\n          <ion-icon\r\n            class='icon-2em'\r\n            color='warning'\r\n            name=\"flag-sharp\"\r\n          ></ion-icon>\r\n        </ion-label>\r\n        <ion-checkbox\r\n          color='warning'\r\n          formControlName='sinalizado'\r\n        ></ion-checkbox>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <div class=\"d-flex justify-content-between align-items-center\">\r\n      <ion-item\r\n        class='ion-padding-bottom'\r\n        [disabled]=\"pickerShow\"\r\n      >\r\n        <ion-label>Data e Hora</ion-label>\r\n        <ion-datetime\r\n          displayFormat=\"DD/MMM/YYYY HH:mm\"\r\n          pickerFormat=\"DD MMM YYYY HH mm\"\r\n          monthShortNames='Jan, Fev, Mar, Abr, Mai, Jun, Jul, Ago, Set, Out, Nov, Dez'\r\n          max=2030\r\n          formControlName='data'\r\n          doneText=\"OK\"\r\n          cancelText=\"Cancelar\"\r\n        ></ion-datetime>\r\n        <app-validator-note [form-control]=\"$any(taskForm.get('data'))\"></app-validator-note>\r\n      </ion-item>\r\n      <ion-item style='padding: 0rem'>\r\n        <ion-label>Hoje</ion-label>\r\n        <ion-toggle\r\n          style='padding: 0.3rem'\r\n          (ionChange)='hojeAction($event)'\r\n        ></ion-toggle>\r\n      </ion-item>\r\n    </div>\r\n\r\n    <ion-toolbar *ngIf='responsaveis.length > 0' class='ion-padding-bottom'>\r\n\r\n      <ion-item>\r\n        <ion-label>Responsável</ion-label>\r\n        <ion-toggle  (ionChange)=\"toggleAccordion($event)\" ></ion-toggle>\r\n      </ion-item>\r\n\r\n    </ion-toolbar>\r\n\r\n    <app-expandable [isOpen]='isOpen' expandHeight=\"450\" [expanded]=\"accordionExpanded\">\r\n        <ion-item  *ngFor=\"let responsavel of responsaveis\">\r\n          <ion-toggle\r\n            slot='start'\r\n            color='primary'\r\n            [checked]='povoaChecked(responsavel.nome)'\r\n            (ionChange)='toogle($event, responsavel.nome)'\r\n          >\r\n            {{responsavel.nome}}\r\n          </ion-toggle>\r\n          <ion-label>{{responsavel.nome}}</ion-label>\r\n        </ion-item>\r\n    </app-expandable>\r\n\r\n\r\n    <ion-button\r\n      [disabled]=\"taskForm.invalid\"\r\n      expand=\"block\"\r\n      type=\"submit\"\r\n      color='medium'\r\n    >\r\n      Salvar\r\n    </ion-button>\r\n\r\n  </form>\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_dashboard_tasks_task-save_task-save_module_ts.js.map