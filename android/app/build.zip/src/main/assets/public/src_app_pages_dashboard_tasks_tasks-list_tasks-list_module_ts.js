(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_dashboard_tasks_tasks-list_tasks-list_module_ts"],{

/***/ 75630:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/tasks-list/tasks-list-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksListPageRoutingModule": () => (/* binding */ TasksListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _tasks_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tasks-list.page */ 72273);




const routes = [
    {
        path: '',
        component: _tasks_list_page__WEBPACK_IMPORTED_MODULE_0__.TasksListPage
    }
];
let TasksListPageRoutingModule = class TasksListPageRoutingModule {
};
TasksListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TasksListPageRoutingModule);



/***/ }),

/***/ 23621:
/*!***********************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/tasks-list/tasks-list.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksListPageModule": () => (/* binding */ TasksListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../responsaveis/services/responsavel.service */ 35400);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/tasks.service */ 42660);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _tasks_list_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tasks-list-routing.module */ 75630);
/* harmony import */ var _tasks_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tasks-list.page */ 72273);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var _shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../shared/directives/directives.module */ 35540);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../etiquetas/services/etiquetas.service */ 49144);











let TasksListPageModule = class TasksListPageModule {
};
TasksListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.SharedModule,
            src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_5__.ComponentsModule,
            _tasks_list_routing_module__WEBPACK_IMPORTED_MODULE_2__.TasksListPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule,
            _shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_6__.DirectivesModule,
        ],
        providers: [_services_tasks_service__WEBPACK_IMPORTED_MODULE_1__.TasksService, _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_7__.EtiquetasService, _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_0__.ResponsavelService],
        declarations: [_tasks_list_page__WEBPACK_IMPORTED_MODULE_3__.TasksListPage],
    })
], TasksListPageModule);



/***/ }),

/***/ 72273:
/*!*********************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/tasks-list/tasks-list.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksListPage": () => (/* binding */ TasksListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_tasks_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tasks-list.page.html */ 52504);
/* harmony import */ var _tasks_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tasks-list.page.scss */ 32980);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/services/overlay.service */ 96994);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/tasks.service */ 42660);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../etiquetas/services/etiquetas.service */ 49144);
/* harmony import */ var _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../responsaveis/services/responsavel.service */ 35400);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment */ 16738);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);




/* eslint-disable @typescript-eslint/no-shadow */












let TasksListPage = class TasksListPage {
    constructor(tasksService, navCtrl, fb, overlayService, etiquetaService, responsavelService, store) {
        this.tasksService = tasksService;
        this.navCtrl = navCtrl;
        this.fb = fb;
        this.overlayService = overlayService;
        this.etiquetaService = etiquetaService;
        this.responsavelService = responsavelService;
        this.store = store;
        //tarefas
        this.tasks = [];
        this.filteredTasks = [];
        this.isOpen = true;
        //etiquetas
        this.etiquetas = [];
        //responsaveis
        this.responsaveis = [];
        this.createForm();
        this.storeAction();
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.actionEtiquetasResponsaveis();
        });
    }
    filterTasks() {
        let newTasks = [...this.tasks];
        const data = (0,_angular_common__WEBPACK_IMPORTED_MODULE_9__.formatDate)(new Date(), 'yyyy-MM-dd', 'en');
        switch (this.faseParam) {
            case 'todos':
                newTasks = newTasks;
                break;
            case 'hoje':
                newTasks = newTasks.filter((r) => (0,_angular_common__WEBPACK_IMPORTED_MODULE_9__.formatDate)(r.data, 'yyyy-MM-dd', 'en') === data && !r.done);
                break;
            case 'vencidos':
                newTasks = newTasks.filter((r) => (0,_angular_common__WEBPACK_IMPORTED_MODULE_9__.formatDate)(r.data, 'yyyy-MM-dd', 'en') < data && !r.done);
                break;
            case 'abertos':
                newTasks = newTasks.filter((r) => r.done === false);
                break;
            case 'finalizados':
                newTasks = newTasks.filter((r) => r.done);
                break;
            case 'sinalizados':
                newTasks = newTasks.filter((r) => r.sinalizado && !r.done);
        }
        if (Boolean(this.etiquetaParam)) {
            newTasks = newTasks.filter((r) => this.etiquetaParam === 'todos' ||
                (r.tipo === this.etiquetaParam && !r.done));
        }
        if (Boolean(this.responsavelParam)) {
            newTasks = newTasks.filter((r) => {
                var _a;
                return this.responsavelParam === 'todos' ||
                    (r.responsavel && ((_a = r.responsavel) === null || _a === void 0 ? void 0 : _a.includes(this.responsavelParam)));
            });
        }
        this.filteredTasks = newTasks;
    }
    onUpdate(task) {
        this.navCtrl.navigateForward(['tasks/edit', task.id]);
    }
    onDone(task) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const taskToUpdate = Object.assign(Object.assign({}, task), { done: !task.done });
            setTimeout(() => {
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddTasks)([taskToUpdate]));
                this.tasksService.update(taskToUpdate);
                this.filterTasks();
                this.cor();
            }, 400);
            yield this.overlayService.toast({
                message: `Tarefa ${task.title} ${taskToUpdate.done ? 'Atualizada' : 'Atualizada'}!`,
            });
        });
    }
    onHoje(task) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const taskToUpdate = Object.assign(Object.assign({}, task), { data: moment__WEBPACK_IMPORTED_MODULE_7__(new Date()).format('YYYY-MM-DDTHH:mmZ') });
            setTimeout(() => {
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddTasks)([taskToUpdate]));
                this.tasksService.update(taskToUpdate);
                this.filterTasks();
                this.cor();
            }, 400);
            yield this.overlayService.toast({
                message: `Tarefa ${task.title} ${taskToUpdate.done ? 'Atualizada' : 'Atualizada'}!`,
            });
        });
    }
    onSinalizada(task) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const taskToUpdate = Object.assign(Object.assign({}, task), { sinalizado: !task.sinalizado });
            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddTasks)([taskToUpdate]));
            this.filterTasks();
            this.cor();
            yield this.tasksService.update(taskToUpdate);
            yield this.overlayService.toast({
                message: `Tarefa ${task.title} ${taskToUpdate.done ? 'Atualizada' : 'Atualizada'}!`,
            });
        });
    }
    getItems(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const val = ev.target.value;
            if (val && val !== '') {
                this.tasks.filter((state) => state.title.toLowerCase().indexOf(val.toLowerCase()) !== -1);
            }
        });
    }
    changeSelect(event) {
        this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionEtiqueta)(event.target.value));
    }
    changeSelectResponsavel(event) {
        this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddSelectionResponsavel)(event.target.value));
    }
    corEtiqueta(tipo) {
        try {
            const cor = this.etiquetas.find((element) => element.nome === tipo);
            return cor.cor;
        }
        catch (e) {
            return;
        }
    }
    cor() {
        switch (this.faseParam) {
            case 'hoje':
                this.color = 'primary';
                break;
            case 'abertos':
                this.color = 'success';
                break;
            case 'vencidos':
                this.color = 'danger';
                break;
            case 'sinalizados':
                this.color = 'warning';
                break;
            case 'todos':
                this.color = 'medium';
                break;
            case 'finalizados':
                this.color = 'primary';
                break;
        }
    }
    createForm() {
        this.taskForm = this.fb.group({
            tipo: [''],
            responsavel: [''],
        });
    }
    actionEtiquetasResponsaveis() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            yield this.etiquetaService
                .getAll()
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.take)(1))
                .subscribe((res) => {
                this.etiquetas = res;
            });
            yield this.responsavelService
                .getAll()
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.take)(1))
                .subscribe((res) => {
                this.responsaveis = res;
            });
        });
    }
    storeAction() {
        this.store.select('selectBox').subscribe((res) => {
            this.faseParam = res.fase;
            this.etiquetaParam = res.etiqueta;
            this.responsavelParam = res.responsavel;
            this.filterTasks();
            this.cor();
        });
        this.store.select('tasks').subscribe((data) => {
            this.tasks = data.tasks;
            this.filterTasks();
            this.cor();
        });
    }
};
TasksListPage.ctorParameters = () => [
    { type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormBuilder },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__.OverlayService },
    { type: _etiquetas_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__.EtiquetasService },
    { type: _responsaveis_services_responsavel_service__WEBPACK_IMPORTED_MODULE_6__.ResponsavelService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_13__.Store }
];
TasksListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-tasks-list',
        template: _raw_loader_tasks_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tasks_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TasksListPage);



/***/ }),

/***/ 32980:
/*!***********************************************************************!*\
  !*** ./src/app/pages/dashboard/tasks/tasks-list/tasks-list.page.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".select {\n  font-weight: bold;\n  font-size: 120% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhc2tzLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSwwQkFBQTtBQUNGIiwiZmlsZSI6InRhc2tzLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdCB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 52504:
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/tasks/tasks-list/tasks-list.page.html ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<app-header-back\r\n  title='Lista de tarefas'\r\n  route='/tasks'\r\n></app-header-back>\r\n\r\n<ion-content padding>\r\n  <ion-text [color]='color'>\r\n    <h1 class='ion-padding-start bold'>{{ faseParam | titlecase}}</h1>\r\n  </ion-text>\r\n  <ion-toolbar>\r\n    <form\r\n      class='ion-padding'\r\n      [formGroup]=\"taskForm\"\r\n    >\r\n      <ion-select\r\n        (ionChange)=\"changeSelectResponsavel($event)\"\r\n        [placeholder]=\"responsavelParam | titlecase\"\r\n        interface=\"action-sheet\"\r\n        okText=\"OK\"\r\n        cancelText=\"Cancelar\"\r\n        formControlName='responsavel'\r\n        class=\"ion-padding select\"\r\n      >\r\n        <ion-select-option\r\n          class='primary'\r\n          value=\"todos\"\r\n        >\r\n          TODOS RESPONSÁVEIS\r\n        </ion-select-option>\r\n        <ion-select-option\r\n          *ngFor='let responsavel of responsaveis'\r\n          value=\"{{ responsavel.nome }}\"\r\n        >\r\n          {{ responsavel.nome }}\r\n        </ion-select-option>\r\n      </ion-select>\r\n      <ion-select\r\n        (ionChange)=\"changeSelect($event)\"\r\n        [placeholder]=\"etiquetaParam | titlecase\"\r\n        interface=\"action-sheet\"\r\n        okText=\"OK\"\r\n        cancelText=\"Cancelar\"\r\n        class=\"ion-padding select\"\r\n        formControlName='tipo'\r\n        [appTaskTipos]='etiquetas'\r\n      >\r\n        <ion-select-option\r\n          class='primary'\r\n          value=\"todos\"\r\n        >\r\n          TODOS\r\n        </ion-select-option>\r\n        <ion-select-option\r\n          *ngFor='let etiqueta of etiquetas'\r\n          value=\"{{ etiqueta.nome }}\"\r\n        >\r\n          <ion-text>\r\n\r\n            <ion-badge [color]='etiqueta.cor'>{{ etiqueta.nome | titlecase }}</ion-badge>\r\n          </ion-text>\r\n        </ion-select-option>\r\n      </ion-select>\r\n    </form>\r\n    <ion-searchbar\r\n      [(ngModel)]=\"filtro\"\r\n      animated=\"true\"\r\n      mode='ios'\r\n      placeholder='Procurar'\r\n    ></ion-searchbar>\r\n  </ion-toolbar>\r\n\r\n  <ion-list\r\n    fullscreen\r\n    *ngIf=\"(tasks) as tasks; else skeleton\"\r\n  >\r\n    <ng-container *ngIf=\"tasks.length > 0; else noTasks\">\r\n      <app-task-item\r\n        *ngFor=\"let task of filteredTasks | filter: filtro\"\r\n        [task]=\"task\"\r\n        (update)=\"onUpdate($event)\"\r\n        (done)=\"onDone($event)\"\r\n        (hoje)=\"onHoje($event)\"\r\n        (sinalizada)=\"onSinalizada($event)\"\r\n        [color]='corEtiqueta(task.tipo)'\r\n      >\r\n      </app-task-item>\r\n\r\n    </ng-container>\r\n\r\n    <ng-template #noTasks>\r\n      <app-no-tasks msg='Nenhuma tarefa ainda...'></app-no-tasks>\r\n    </ng-template>\r\n\r\n  </ion-list>\r\n\r\n  <ng-template #skeleton>\r\n    <app-skeleton-list\r\n      [qtd]='5'\r\n      heigth='5rem'\r\n    ></app-skeleton-list>\r\n  </ng-template>\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_dashboard_tasks_tasks-list_tasks-list_module_ts.js.map