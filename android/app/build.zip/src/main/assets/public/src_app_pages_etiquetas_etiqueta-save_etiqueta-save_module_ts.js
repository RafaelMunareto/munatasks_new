(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_etiquetas_etiqueta-save_etiqueta-save_module_ts"],{

/***/ 15004:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/etiquetas/etiqueta-save/etiqueta-save-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaSavePageRoutingModule": () => (/* binding */ EtiquetaSavePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _etiqueta_save_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./etiqueta-save.page */ 26231);




const routes = [
    {
        path: '',
        component: _etiqueta_save_page__WEBPACK_IMPORTED_MODULE_0__.EtiquetaSavePage
    }
];
let EtiquetaSavePageRoutingModule = class EtiquetaSavePageRoutingModule {
};
EtiquetaSavePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EtiquetaSavePageRoutingModule);



/***/ }),

/***/ 55478:
/*!***********************************************************************!*\
  !*** ./src/app/pages/etiquetas/etiqueta-save/etiqueta-save.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaSavePageModule": () => (/* binding */ EtiquetaSavePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _etiqueta_save_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./etiqueta-save-routing.module */ 15004);
/* harmony import */ var _etiqueta_save_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etiqueta-save.page */ 26231);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var src_app_shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/directives/directives.module */ 35540);
/* harmony import */ var _services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/etiquetas.service */ 49144);








let EtiquetaSavePageModule = class EtiquetaSavePageModule {
};
EtiquetaSavePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
            src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__.ComponentsModule,
            _etiqueta_save_routing_module__WEBPACK_IMPORTED_MODULE_0__.EtiquetaSavePageRoutingModule,
            src_app_shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_4__.DirectivesModule,
        ],
        declarations: [_etiqueta_save_page__WEBPACK_IMPORTED_MODULE_1__.EtiquetaSavePage],
        providers: [_services_etiquetas_service__WEBPACK_IMPORTED_MODULE_5__.EtiquetasService],
    })
], EtiquetaSavePageModule);



/***/ }),

/***/ 26231:
/*!*********************************************************************!*\
  !*** ./src/app/pages/etiquetas/etiqueta-save/etiqueta-save.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaSavePage": () => (/* binding */ EtiquetaSavePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_etiqueta_save_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./etiqueta-save.page.html */ 54772);
/* harmony import */ var _etiqueta_save_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etiqueta-save.page.scss */ 28141);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../core/services/overlay.service */ 96994);
/* harmony import */ var _services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/etiquetas.service */ 49144);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngrx/store */ 86710);












let EtiquetaSavePage = class EtiquetaSavePage {
    constructor(fb, etiquetaService, overlayService, route, navCtrl, store) {
        this.fb = fb;
        this.etiquetaService = etiquetaService;
        this.overlayService = overlayService;
        this.route = route;
        this.navCtrl = navCtrl;
        this.store = store;
        this.pageTitle = '...';
        this.etiquetaId = undefined;
    }
    ngOnInit() {
        this.createForm();
    }
    ionViewDidEnter() {
        this.init();
    }
    init() {
        const etiquetaId = this.route.snapshot.paramMap.get('id');
        if (!etiquetaId) {
            this.pageTitle = 'Criar Etiqueta';
            return;
        }
        this.etiquetaId = etiquetaId;
        this.pageTitle = 'Editar Etiqueta';
        this.etiquetaService
            .get(etiquetaId)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.take)(1))
            .subscribe(({ nome, cor }) => {
            this.etiquetaForm.get('nome').setValue(nome);
            this.etiquetaForm.get('cor').setValue(cor);
        });
    }
    onSubmit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.overlayService.loading({
                message: 'Salvando ...',
            });
            try {
                const etiqueta = !this.etiquetaId
                    ? yield this.etiquetaService.create(this.etiquetaForm.value)
                    : yield this.etiquetaService.update(Object.assign({ id: this.etiquetaId }, this.etiquetaForm.value));
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddEtiquetas)([etiqueta]));
                this.etiquetaForm.reset();
                this.navCtrl.back();
            }
            catch (error) {
                yield this.overlayService.toast({
                    message: error.message,
                });
            }
            finally {
                loading.dismiss();
            }
        });
    }
    get nome() {
        return this.etiquetaForm.get('nome');
    }
    createForm() {
        this.etiquetaForm = this.fb.group({
            nome: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(3)]],
            cor: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(3)]],
        });
    }
};
EtiquetaSavePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _services_etiquetas_service__WEBPACK_IMPORTED_MODULE_4__.EtiquetasService },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__.OverlayService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_10__.Store }
];
EtiquetaSavePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        template: _raw_loader_etiqueta_save_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_etiqueta_save_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EtiquetaSavePage);



/***/ }),

/***/ 28141:
/*!***********************************************************************!*\
  !*** ./src/app/pages/etiquetas/etiqueta-save/etiqueta-save.page.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".select {\n  font-weight: bold;\n  font-size: 120% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV0aXF1ZXRhLXNhdmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSwwQkFBQTtBQUNGIiwiZmlsZSI6ImV0aXF1ZXRhLXNhdmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdCB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 54772:
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/etiquetas/etiqueta-save/etiqueta-save.page.html ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot='start'>\r\n      <ion-back-button defaultHref=\"/tasks\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{ pageTitle }}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <form\r\n    class='ion-padding'\r\n    [formGroup]=\"etiquetaForm\"\r\n    (submit)=\"onSubmit()\"\r\n  >\r\n    <ion-item>\r\n      <ion-input\r\n        name='nome'\r\n        placeholder='Etiqueta'\r\n        formControlName='nome'\r\n        [autofocus]='true'\r\n      ></ion-input>\r\n      <app-validator-note [form-control]=\"$any(etiquetaForm.get('nome'))\"></app-validator-note>\r\n    </ion-item>\r\n\r\n    <ion-row>\r\n      <ion-col size='12'>\r\n        <ion-select\r\n          placeholder=\"Selecione uma cor\"\r\n          interface=\"action-sheet\"\r\n          okText=\"OK\"\r\n          cancelText=\"Cancelar\"\r\n          class=\"ion-padding select\"\r\n          formControlName='cor'\r\n          appEtiquetasColors\r\n        >\r\n          <ion-select-option value=\"danger\">Vermelho</ion-select-option>\r\n          <ion-select-option value=\"warning\">Amarelo</ion-select-option>\r\n          <ion-select-option value=\"success\">Verde</ion-select-option>\r\n          <ion-select-option value=\"secondary\">Azul claro</ion-select-option>\r\n          <ion-select-option value=\"primary\">Azul</ion-select-option>\r\n          <ion-select-option value=\"medium\">Cinza</ion-select-option>\r\n          <ion-select-option value=\"dark\">Preto</ion-select-option>\r\n        </ion-select>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n\r\n    <ion-button\r\n      [disabled]=\"etiquetaForm.invalid\"\r\n      expand=\"block\"\r\n      type=\"submit\"\r\n      color='medium'\r\n    >\r\n      Salvar\r\n    </ion-button>\r\n\r\n  </form>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_etiquetas_etiqueta-save_etiqueta-save_module_ts.js.map