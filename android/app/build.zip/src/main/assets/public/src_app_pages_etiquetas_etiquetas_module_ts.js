(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_etiquetas_etiquetas_module_ts"],{

/***/ 90879:
/*!*************************************************************!*\
  !*** ./src/app/pages/etiquetas/etiquetas-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetasRoutingModule": () => (/* binding */ EtiquetasRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/guards/auth.guard */ 27574);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _etiquetas_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etiquetas.component */ 73050);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);





const routes = [
    {
        path: '',
        component: _etiquetas_component__WEBPACK_IMPORTED_MODULE_1__.EtiquetasComponent,
        canActivateChild: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        children: [
            {
                path: 'edit/:id',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_components_module_ts"), __webpack_require__.e("src_app_pages_etiquetas_etiqueta-save_etiqueta-save_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./etiqueta-save/etiqueta-save.module */ 55478)).then((m) => m.EtiquetaSavePageModule),
            },
            {
                path: 'create',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_components_module_ts"), __webpack_require__.e("src_app_pages_etiquetas_etiqueta-save_etiqueta-save_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./etiqueta-save/etiqueta-save.module */ 55478)).then((m) => m.EtiquetaSavePageModule),
            },
        ],
    },
];
let EtiquetasRoutingModule = class EtiquetasRoutingModule {
};
EtiquetasRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    })
], EtiquetasRoutingModule);



/***/ }),

/***/ 73050:
/*!********************************************************!*\
  !*** ./src/app/pages/etiquetas/etiquetas.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetasComponent": () => (/* binding */ EtiquetasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_etiquetas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./etiquetas.component.html */ 30444);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);



let EtiquetasComponent = class EtiquetasComponent {
};
EtiquetasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-etiquetas',
        template: _raw_loader_etiquetas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
    })
], EtiquetasComponent);



/***/ }),

/***/ 87376:
/*!*****************************************************!*\
  !*** ./src/app/pages/etiquetas/etiquetas.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetasModule": () => (/* binding */ EtiquetasModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _etiquetas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./etiquetas-routing.module */ 90879);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _etiquetas_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./etiquetas.component */ 73050);





let EtiquetasModule = class EtiquetasModule {
};
EtiquetasModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_etiquetas_component__WEBPACK_IMPORTED_MODULE_2__.EtiquetasComponent],
        imports: [_etiquetas_routing_module__WEBPACK_IMPORTED_MODULE_0__.EtiquetasRoutingModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
    })
], EtiquetasModule);



/***/ }),

/***/ 30444:
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/etiquetas/etiquetas.component.html ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\r\n  <ion-router-outlet id='menu-content'></ion-router-outlet>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_etiquetas_etiquetas_module_ts.js.map