(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_responsaveis_responsaveis-list_responsaveis-list_module_ts"],{

/***/ 20854:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-list/responsaveis-list-routing.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsibleListPageRoutingModule": () => (/* binding */ ResponsibleListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _responsaveis_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./responsaveis-list.page */ 84745);




const routes = [
    {
        path: '',
        component: _responsaveis_list_page__WEBPACK_IMPORTED_MODULE_0__.ResponssaveisListPage,
    },
];
let ResponsibleListPageRoutingModule = class ResponsibleListPageRoutingModule {
};
ResponsibleListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ResponsibleListPageRoutingModule);



/***/ }),

/***/ 80213:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-list/responsaveis-list.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisListPageModule": () => (/* binding */ ResponsaveisListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _responsaveis_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./responsaveis-list-routing.module */ 20854);
/* harmony import */ var _responsaveis_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./responsaveis-list.page */ 84745);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var _services_responsavel_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../services/responsavel.service */ 35400);








let ResponsaveisListPageModule = class ResponsaveisListPageModule {
};
ResponsaveisListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_3__.ComponentsModule, _responsaveis_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.ResponsibleListPageRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule],
        declarations: [_responsaveis_list_page__WEBPACK_IMPORTED_MODULE_1__.ResponssaveisListPage],
        providers: [_services_responsavel_service__WEBPACK_IMPORTED_MODULE_4__.ResponsavelService],
    })
], ResponsaveisListPageModule);



/***/ }),

/***/ 84745:
/*!********************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-list/responsaveis-list.page.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponssaveisListPage": () => (/* binding */ ResponssaveisListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_responsaveis_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./responsaveis-list.page.html */ 82537);
/* harmony import */ var _responsaveis_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./responsaveis-list.page.scss */ 27317);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ 86710);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../core/services/overlay.service */ 96994);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 87519);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 88002);
/* harmony import */ var _services_responsavel_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../services/responsavel.service */ 35400);










let ResponssaveisListPage = class ResponssaveisListPage {
    constructor(navCtrl, responsaveisService, store, overlayService) {
        this.navCtrl = navCtrl;
        this.responsaveisService = responsaveisService;
        this.store = store;
        this.overlayService = overlayService;
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.overlayService.loading();
            this.responsaveis$ = this.store.pipe((0,_ngrx_store__WEBPACK_IMPORTED_MODULE_6__.select)('responsaveis'));
            this.responsaveis$ = this.responsaveisService.getAll();
            this.responsaveis$.subscribe(() => {
                loading.dismiss();
            });
        });
    }
    onUpdate(responsavel) {
        this.navCtrl.navigateForward(['/responsaveis', 'edit', responsavel.id]);
    }
    onDelete(responsavel) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.overlayService.alert({
                message: `Tem certeza que deseja excluír o responsável ${responsavel.nome} ?`,
                buttons: [
                    {
                        text: 'Sim',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                            yield this.responsaveisService.delete(responsavel);
                            yield this.overlayService.toast({
                                message: `Responsável ${responsavel.nome} deletado!`,
                            });
                            this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.RemoveResponsavel)(responsavel.id));
                        }),
                    },
                    'Não',
                ],
            });
        });
    }
    getItems(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const val = ev.target.value;
            if (val && val !== '') {
                this.responsaveis$ = this.responsaveis$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)((res) => res.filter((state) => state.nome.toLowerCase().indexOf(val.toLowerCase()) !== -1)));
            }
        });
    }
};
ResponssaveisListPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _services_responsavel_service__WEBPACK_IMPORTED_MODULE_4__.ResponsavelService },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_6__.Store },
    { type: _core_services_overlay_service__WEBPACK_IMPORTED_MODULE_3__.OverlayService }
];
ResponssaveisListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        template: _raw_loader_responsaveis_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_responsaveis_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ResponssaveisListPage);



/***/ }),

/***/ 27317:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-list/responsaveis-list.page.scss ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXNwb25zYXZlaXMtbGlzdC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 82537:
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/responsaveis/responsaveis-list/responsaveis-list.page.html ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot='start'>\r\n      <ion-back-button defaultHref=\"/tasks\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-buttons slot='end'>\r\n      <ion-button\r\n        routerLink=\"create\"\r\n        routerDirection=\"forward\"\r\n      >\r\n        <ion-icon\r\n          slot=\"icon-only\"\r\n          name=\"add-circle-outline\"\r\n        ></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>Responsáveis</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-toolbar class='ion-padding-top'>\r\n    <ion-searchbar\r\n      [(ngModel)]=\"filtro\"\r\n      animated=\"true\"\r\n      mode='ios'\r\n      placeholder='Procurar'\r\n    ></ion-searchbar>\r\n  </ion-toolbar>\r\n\r\n  <ion-list\r\n    fullscreen\r\n    *ngIf=\"(responsaveis$ | async) as responsaveis\"\r\n  >\r\n    <ng-container *ngIf=\"responsaveis.length > 0; else noTags\">\r\n      <app-responsaveis-item\r\n        *ngFor=\"let responsavel of responsaveis | filter: filtro\"\r\n        [responsaveis]=\"responsavel\"\r\n        (update)=\"onUpdate($event)\"\r\n        (delete)=\"onDelete($event)\"\r\n      >\r\n      </app-responsaveis-item>\r\n\r\n    </ng-container>\r\n\r\n    <ng-template #noTags>\r\n      <ion-item lines=\"none\">Nenhum Responsável ainda...</ion-item>\r\n    </ng-template>\r\n\r\n  </ion-list>\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_responsaveis_responsaveis-list_responsaveis-list_module_ts.js.map