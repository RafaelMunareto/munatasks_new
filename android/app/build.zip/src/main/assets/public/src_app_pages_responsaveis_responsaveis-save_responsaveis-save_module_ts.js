(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_responsaveis_responsaveis-save_responsaveis-save_module_ts"],{

/***/ 62604:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-save/responsaveis-save-routing.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsibleSavePageRoutingModule": () => (/* binding */ ResponsibleSavePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _responsaveis_save_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./responsaveis-save.page */ 59319);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);




const routes = [
    {
        path: '',
        component: _responsaveis_save_page__WEBPACK_IMPORTED_MODULE_0__.ResponsaveisSavePage,
    },
];
let ResponsibleSavePageRoutingModule = class ResponsibleSavePageRoutingModule {
};
ResponsibleSavePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ResponsibleSavePageRoutingModule);



/***/ }),

/***/ 59614:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-save/responsaveis-save.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisSavePageModule": () => (/* binding */ ResponsaveisSavePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _services_responsavel_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/responsavel.service */ 35400);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/components/components.module */ 15626);
/* harmony import */ var src_app_shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/directives/directives.module */ 35540);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _responsaveis_save_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./responsaveis-save-routing.module */ 62604);
/* harmony import */ var _responsaveis_save_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./responsaveis-save.page */ 59319);








let ResponsaveisSavePageModule = class ResponsaveisSavePageModule {
};
ResponsaveisSavePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            src_app_shared_components_components_module__WEBPACK_IMPORTED_MODULE_1__.ComponentsModule,
            src_app_shared_directives_directives_module__WEBPACK_IMPORTED_MODULE_2__.DirectivesModule,
            _responsaveis_save_routing_module__WEBPACK_IMPORTED_MODULE_4__.ResponsibleSavePageRoutingModule,
        ],
        declarations: [_responsaveis_save_page__WEBPACK_IMPORTED_MODULE_5__.ResponsaveisSavePage],
        providers: [_services_responsavel_service__WEBPACK_IMPORTED_MODULE_0__.ResponsavelService],
    })
], ResponsaveisSavePageModule);



/***/ }),

/***/ 59319:
/*!********************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-save/responsaveis-save.page.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisSavePage": () => (/* binding */ ResponsaveisSavePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_responsaveis_save_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./responsaveis-save.page.html */ 7245);
/* harmony import */ var _responsaveis_save_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./responsaveis-save.page.scss */ 63130);
/* harmony import */ var _core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/ngrx/actions/action-types */ 65221);
/* harmony import */ var _services_responsavel_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/responsavel.service */ 35400);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 15257);
/* harmony import */ var src_app_core_services_overlay_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/overlay.service */ 96994);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngrx/store */ 86710);












let ResponsaveisSavePage = class ResponsaveisSavePage {
    constructor(fb, responsavelService, overlayService, route, navCtrl, store) {
        this.fb = fb;
        this.responsavelService = responsavelService;
        this.overlayService = overlayService;
        this.route = route;
        this.navCtrl = navCtrl;
        this.store = store;
        this.pageTitle = '...';
        this.responsavelId = undefined;
    }
    ngOnInit() {
        this.createForm();
    }
    ionViewDidEnter() {
        this.init();
    }
    init() {
        const responsavelId = this.route.snapshot.paramMap.get('id');
        if (!responsavelId) {
            this.pageTitle = 'Criar Responsável';
            return;
        }
        this.responsavelId = responsavelId;
        this.pageTitle = 'Editar Responsável';
        this.responsavelService
            .get(responsavelId)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.take)(1))
            .subscribe(({ nome }) => {
            this.responsavelForm.get('nome').setValue(nome);
        });
    }
    onSubmit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.overlayService.loading({
                message: 'Salvando ...',
            });
            try {
                const responsavel = !this.responsavelId
                    ? yield this.responsavelService.create(this.responsavelForm.value)
                    : yield this.responsavelService.update(Object.assign({ id: this.responsavelId }, this.responsavelForm.value));
                this.store.dispatch((0,_core_ngrx_actions_action_types__WEBPACK_IMPORTED_MODULE_2__.AddResponsavel)([responsavel]));
                this.responsavelForm.reset();
                this.navCtrl.back();
            }
            catch (error) {
                yield this.overlayService.toast({
                    message: error.message,
                });
            }
            finally {
                loading.dismiss();
            }
        });
    }
    get nome() {
        return this.responsavelForm.get('nome');
    }
    createForm() {
        this.responsavelForm = this.fb.group({
            nome: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(3)]],
        });
    }
};
ResponsaveisSavePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _services_responsavel_service__WEBPACK_IMPORTED_MODULE_3__.ResponsavelService },
    { type: src_app_core_services_overlay_service__WEBPACK_IMPORTED_MODULE_4__.OverlayService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _ngrx_store__WEBPACK_IMPORTED_MODULE_10__.Store }
];
ResponsaveisSavePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-responsaveis-save',
        template: _raw_loader_responsaveis_save_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_responsaveis_save_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ResponsaveisSavePage);



/***/ }),

/***/ 63130:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-save/responsaveis-save.page.scss ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXNwb25zYXZlaXMtc2F2ZS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 7245:
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/responsaveis/responsaveis-save/responsaveis-save.page.html ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot='start'>\r\n      <ion-back-button defaultHref=\"/responsaveis\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{ pageTitle }}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <form\r\n    class='ion-padding'\r\n    [formGroup]=\"responsavelForm\"\r\n    (submit)=\"onSubmit()\"\r\n  >\r\n    <ion-item>\r\n      <ion-input\r\n        name='nome'\r\n        placeholder='Responsável'\r\n        formControlName='nome'\r\n        [autofocus]='true'\r\n      ></ion-input>\r\n      <app-validator-note [form-control]=\"$any(responsavelForm.get('nome'))\"></app-validator-note>\r\n    </ion-item>\r\n\r\n    <ion-button\r\n      [disabled]=\"responsavelForm.invalid\"\r\n      expand=\"block\"\r\n      type=\"submit\"\r\n      color='medium'\r\n    >\r\n      Salvar\r\n    </ion-button>\r\n\r\n  </form>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_responsaveis_responsaveis-save_responsaveis-save_module_ts.js.map