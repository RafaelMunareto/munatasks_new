(self["webpackChunkMunaTasks"] = self["webpackChunkMunaTasks"] || []).push([["src_app_pages_responsaveis_responsaveis_module_ts"],{

/***/ 89437:
/*!*******************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisPageRoutingModule": () => (/* binding */ ResponsaveisPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/guards/auth.guard */ 27574);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _responsaveis_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./responsaveis.component */ 56393);





const routes = [
    {
        path: '',
        component: _responsaveis_component__WEBPACK_IMPORTED_MODULE_1__.ResponsaveisComponent,
        canActivateChild: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        children: [
            {
                path: 'create',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_components_module_ts"), __webpack_require__.e("src_app_pages_responsaveis_responsaveis-save_responsaveis-save_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./responsaveis-save/responsaveis-save.module */ 59614)).then((m) => m.ResponsaveisSavePageModule),
            },
            {
                path: 'edit/:id',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_components_module_ts"), __webpack_require__.e("src_app_pages_responsaveis_responsaveis-save_responsaveis-save_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./responsaveis-save/responsaveis-save.module */ 59614)).then((m) => m.ResponsaveisSavePageModule),
            },
            {
                path: '',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_components_module_ts"), __webpack_require__.e("src_app_pages_responsaveis_responsaveis-list_responsaveis-list_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./responsaveis-list/responsaveis-list.module */ 80213)).then((m) => m.ResponsaveisListPageModule),
            },
        ],
    },
];
let ResponsaveisPageRoutingModule = class ResponsaveisPageRoutingModule {
};
ResponsaveisPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    })
], ResponsaveisPageRoutingModule);



/***/ }),

/***/ 56393:
/*!**************************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisComponent": () => (/* binding */ ResponsaveisComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_responsaveis_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./responsaveis.component.html */ 53032);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);



let ResponsaveisComponent = class ResponsaveisComponent {
};
ResponsaveisComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-responsaveis',
        template: _raw_loader_responsaveis_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
    })
], ResponsaveisComponent);



/***/ }),

/***/ 20950:
/*!***********************************************************!*\
  !*** ./src/app/pages/responsaveis/responsaveis.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResponsaveisPageModule": () => (/* binding */ ResponsaveisPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _responsaveis_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./responsaveis-routing.module */ 89437);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _responsaveis_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./responsaveis.component */ 56393);





let ResponsaveisPageModule = class ResponsaveisPageModule {
};
ResponsaveisPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_responsaveis_component__WEBPACK_IMPORTED_MODULE_2__.ResponsaveisComponent],
        imports: [src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _responsaveis_routing_module__WEBPACK_IMPORTED_MODULE_0__.ResponsaveisPageRoutingModule],
    })
], ResponsaveisPageModule);



/***/ }),

/***/ 53032:
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/responsaveis/responsaveis.component.html ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\r\n  <ion-router-outlet id='menu-content'></ion-router-outlet>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_responsaveis_responsaveis_module_ts.js.map